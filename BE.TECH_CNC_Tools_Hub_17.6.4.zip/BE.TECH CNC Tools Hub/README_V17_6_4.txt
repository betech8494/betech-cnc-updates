BE.TECH CNC Tools Hub v17.6.4

FIXED
- Pressing Enter while focused in Username or Password now triggers the same Login button action as a mouse click.
- Enter default behavior is cancelled so the Aspire HTML dialog does not close.

UNCHANGED
- Licensing logic
- Online update system
- SYNTEC export / drill / ATC logic
- Slot Generator
- Cabinet System
- Hinge Drill

Base: restored stable v17.6.3.

BE.TECH CNC Tools Hub v17.5 - Download Update

Built on the confirmed-working v17.4.1 online update system.

NEW
- Download Update button.
- Reads download_url from the ONLINE manifest.
- HTTPS-only update package URL.
- Downloads ZIP into:
  <Gadget Folder>\updates\
- Uses curl.exe with redirects, HTTP failure handling and timeouts.
- Verifies that the downloaded file is non-empty.
- Does NOT extract, replace or install anything automatically yet.

SAFE BEHAVIOR
- No download if installed version is already current.
- No download if download_url is missing.
- No download from non-HTTPS URLs.
- No change to the working Gadget files.

TEST FLOW
1. Install v17.5 and keep your existing license.dat.
2. Upload BE.TECH_TEST_UPDATE_17.5.1.zip somewhere with a direct HTTPS URL.
3. On GitHub Pages edit update_manifest.txt:
   latest_version=17.5.1
   download_url=<DIRECT HTTPS ZIP URL>
4. Click Check Updates Online.
5. Click Download Update.
6. Verify the ZIP appears in the Gadget's updates folder.

UNCHANGED
- SYNTEC logic.
- Drill/ATC logic.
- Slot Generator.
- Cabinet System.
- Hinge Drill.
- Licensing / machine binding / activation.

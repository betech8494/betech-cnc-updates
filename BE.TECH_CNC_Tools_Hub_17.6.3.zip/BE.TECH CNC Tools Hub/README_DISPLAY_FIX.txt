BE.TECH CNC Tools Hub v17.1 Display Fix

Changes:
- Fixed license/modules text overflow in login/license panel.
- Added wrapping for long module lists.
- Added spaces after commas in the displayed Modules list.

Recommended replacement:
- Replace SyntecConverter.html
- Replace BE.TECH CNC Tools Hub.lua
- Keep your existing license.dat file.

BE.TECH CNC Tools Hub v17.6.1 - Installer Fix 2

FIXED:
- installer_status_display() was referenced by main() but missing from the Lua file.
- Added install_result_path(), read_install_result(), and installer_status_display()
  before create_install_script() and before main().
- No CNC, licensing, update-download, prepare, or install-copy logic changed.

Use this build instead of the previous v17.6.1 Installer Launch Fix.
Keep your existing license.dat and update_config.txt.

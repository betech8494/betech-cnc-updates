BE.TECH CNC Tools Hub - RESTORED STABLE 17.6.3

This package restores the last field-tested stable baseline.

Confirmed workflow:
- Online update check
- Download update ZIP
- Prepare / validate update
- Safe installer launch
- Wait for Aspire to close
- Install update
- Reopen Aspire on new version
- Preserve license.dat
- Preserve update_config.txt

Removed from the development direction:
- Cleanup feature
- Rollback UI
- Rollback status
- Rollback safety backup workflow
- Later 17.7.x verification experiments

IMPORTANT:
Keep your existing license.dat.
Keep your existing update_config.txt if already working.

BE.TECH CNC Tools Hub v17.5 - Online Config Fix

FIXED:
- update_config.txt now contains the live GitHub Pages manifest URL:
  https://betech8494.github.io/betech-cnc-updates/update_manifest.txt

EXPECTED TEST:
1. Keep your existing license.dat.
2. Replace the v17.5 files with this package.
3. Restart Aspire.
4. Click "בדוק עדכונים אונליין".
   Expected: Source ONLINE, Latest 17.5.1.
5. Click "הורד עדכון".
   Expected: ZIP downloads into the Gadget's updates folder.

No SYNTEC / Slot / Cabinet / Hinge / licensing logic changed.

BE.TECH CNC Tools Hub v17.4.1

Built on confirmed-working v17.4.

FIXED:
- Aspire update popup now uses real line breaks.
- No more visible \n text in update messages.
- Local and server manifest versions updated to 17.4.1.
- update_config.txt includes a clear HTTPS URL example.

UNCHANGED:
- Online update logic.
- Local fallback logic.
- SYNTEC export/conversion.
- Slot Generator.
- Cabinet System.
- Hinge Drill.
- Licensing and activation flow.

Keep your existing license.dat.

NEXT:
After this display fix is verified, configure a real HTTPS manifest URL
inside update_config.txt and test ONLINE source end-to-end.

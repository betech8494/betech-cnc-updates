BE.TECH CNC Tools Hub v17.4 - Online Update Check

Built directly on confirmed-working v17.3 Update System.

WHAT IS NEW
- "Check Updates Online" fetches a remote HTTPS manifest.
- Windows curl.exe is used explicitly.
- HTTP error handling and redirects.
- 5 second connection timeout.
- 12 second overall timeout.
- Online manifest product validation.
- If online fails, the Hub falls back to update_manifest.txt.
- UI shows ONLINE / LOCAL FALLBACK source.
- No automatic download/install yet.

SETUP
1. Upload SERVER_FILES/update_manifest.txt to HTTPS hosting.
2. Obtain a DIRECT URL to the raw text file.
3. Open update_config.txt.
4. Set:
   manifest_url=https://your-domain/path/update_manifest.txt
5. Restart the Gadget and press "Check Updates Online".

TESTING WITHOUT A SERVER
If manifest_url is blank, the button will intentionally use LOCAL FALLBACK.
This verifies that failure handling is safe.

IMPORTANT
- Keep your existing license.dat.
- No SYNTEC / Slot / Cabinet / Hinge logic was changed.
- Do not distribute SERVER_FILES as part of a customer installer later;
  it is the publisher-side manifest template.

BE.TECH CNC Tools Hub v17.6.1 - Installer Launch Fix

FIXED
- Simplified background installer launch.
- Installer now writes install_result.txt states:
  WAITING
  BACKUP_START
  BACKUP_OK
  INSTALLING
  INSTALLED_<version>
  BACKUP_FAILED
  INSTALL_FAILED
- Hub reads the last installer result on startup.
- Added "Refresh Install Status" button.

UNCHANGED
- Update download
- Prepare validation
- license.dat preservation
- update_config.txt preservation
- SYNTEC / Slot / Cabinet / Hinge / licensing logic

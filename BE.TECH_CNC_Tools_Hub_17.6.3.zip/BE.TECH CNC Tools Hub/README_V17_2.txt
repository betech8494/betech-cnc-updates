BE.TECH CNC Tools Hub v17.2 UI Pro

Built directly on the confirmed-working v17.1 stable build.

UI-only improvements:
- Professional Hub header.
- Customer / License ID / Expiry / Machine ID shown in Hub.
- Four active modules displayed in a clean 2x2 layout.
- Future Tools moved to a dedicated expansion row.
- Improved module descriptions and status presentation.
- Existing long Modules text wrapping retained.

UNCHANGED:
- SYNTEC conversion/export logic.
- SLOT GENERATOR logic.
- CABINET SYSTEM logic.
- HINGE DRILL logic.
- Machine binding, signed licensing, user/password and activation request workflow.

IMPORTANT:
Keep your existing license.dat when replacing the Gadget files.

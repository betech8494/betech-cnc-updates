BE.TECH CNC Tools Hub v17.3 - Update System v1

Built directly on confirmed-working v17.2 UI Pro Stable.

NEW:
- Installed version shown in Hub.
- Latest version read from update_manifest.txt.
- Stable update channel.
- Check Updates button.
- Version comparison.
- Update notes support.

V1 is intentionally offline-safe and does not download from the internet.
Next stage: connect the manifest to a BE.TECH server/API after Aspire testing.

UNCHANGED:
- SYNTEC export/conversion logic.
- Drill-head / ATC logic.
- Slot Generator.
- Cabinet System.
- Hinge Drill.
- Licensing, machine binding and activation request.

Keep your existing license.dat.

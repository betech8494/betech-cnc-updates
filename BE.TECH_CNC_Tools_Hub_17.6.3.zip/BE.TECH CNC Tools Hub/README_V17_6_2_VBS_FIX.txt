BE.TECH CNC Tools Hub v17.6.2 - Installer VBS Launcher Fix

FIXED
- Replaced fragile Windows START command with a WScript/VBScript detached launcher.
- The VBS launcher starts install_prepared_update.cmd hidden and asynchronously.
- The Hub waits briefly for install_result.txt and confirms the installer really started.
- Existing status states remain:
  WAITING
  BACKUP_START
  BACKUP_OK
  INSTALLING
  INSTALLED_<version>
  BACKUP_FAILED
  INSTALL_FAILED

UNCHANGED
- Online update check
- ZIP download
- Prepare/validation
- backup/install copy logic
- license.dat preservation
- update_config.txt preservation
- SYNTEC / Slot / Cabinet / Hinge / licensing logic

BE.TECH CNC Tools Hub v17.0

ACTIVE MODULES:
1. SYNTEC_EXPORT
2. SLOT_GENERATOR
3. CABINET_SYSTEM
4. HINGE_DRILL

HINGE_DRILL:
- Integrated BE.TECH Hinge Drill Generator beta4.
- Requires HINGE_DRILL in license.dat.
- Supports door outline, hinge cups, screw holes, left/right side and 2-4 hinges.
- Uses its own HTML_Dialog and isolated Lua namespace.

UNCHANGED:
- SYNTEC export/conversion core
- Drill/ATC logic
- Slot Generator geometry
- Cabinet System geometry/hardware logic
- Signed licensing engine
- Activation request workflow

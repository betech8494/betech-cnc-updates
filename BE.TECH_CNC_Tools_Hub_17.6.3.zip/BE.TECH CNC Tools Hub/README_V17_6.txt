BE.TECH CNC Tools Hub v17.6 - Safe Update Installer

Flow:
Check -> Download -> Prepare -> Install Prepared Update -> Close Aspire -> Reopen Aspire.

Prepare:
- extracts ZIP into updates\staging
- validates required Hub files
- validates the package APP_VERSION
- does not replace active files

Install:
- launches a background installer
- waits until Aspire.exe closes
- backs up the current Gadget into backups\before_<version>
- preserves license.dat
- preserves update_config.txt
- copies the validated payload

No CNC/tool logic changed.

BE.TECH CNC Tools Hub v17.7 - Cleanup + Rollback

Adds safe cleanup and rollback. Backups, license.dat, and update_config.txt are preserved. Rollback is user-controlled for first validation.

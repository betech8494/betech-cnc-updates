-- VECTRIC LUA SCRIPT

g_title = "BE.TECH Aspire to Syntec Converter"
dialog = nil
g_script_path = ""
g_last_output = ""

local PRODUCT_NAME = "BE.TECH Direct SYNTEC Export"
local PRODUCT_ID = "BETECH-SYNTEC-EXPORT"
local APP_VERSION = "17.6.1"
local g_license = nil

local function trim(s)
   if s == nil then return "" end
   return (s:gsub("^%s*(.-)%s*$", "%1"))
end


-- LOCAL LOGIN PROTECTION V6.4
local AUTH_USER = "admin"

local function simple_hash(s)
   local h1 = 2166136261
   local h2 = 1315423911
   local i = 1
   while i <= #s do
      local c = string.byte(s, i)
      h1 = (h1 * 16777619 + c) % 4294967296
      h2 = (h2 + ((h2 * 32) % 4294967296) + c + math.floor(h2 / 4)) % 4294967296
      i = i + 1
   end
   return string.format("%08x%08x", h1, h2)
end

local AUTH_PASS_LOCAL = simple_hash("Betech2026!")




local function upper(s)
   return string.upper(trim(s))
end

local function dirname(path)
   if path == nil then return "" end
   return path:match("^(.*)[\\/][^\\/]*$") or ""
end

local function basename_no_ext(path)
   if path == nil then return "" end
   local name = path:match("([^\\/]+)$") or path
   return name:gsub("%.[^%.]+$", "")
end

local function join_path(a, b)
   if a == nil or a == "" then return b end
   local last = a:sub(-1)
   if last == "\\" or last == "/" then return a .. b end
   return a .. "\\" .. b
end

local function settings_path()
   return join_path(g_script_path, "SyntecConverter.settings")
end

local function read_all(path)
   local f, err = io.open(path, "rb")
   if f == nil then return nil, err end
   local data = f:read("*all")
   f:close()
   return data
end

local function write_all(path, data)
   local f, err = io.open(path, "wb")
   if f == nil then return false, err end
   f:write(data)
   f:close()
   return true
end


-- =========================
-- LICENSING FOUNDATION V7
-- Local development license now; server/machine binding will use same model later.
-- =========================

local function license_path()
   return join_path(g_script_path, "license.dat")
end

local function machine_id()
   local computer = os.getenv("COMPUTERNAME") or "UNKNOWN-PC"
   local processor = os.getenv("PROCESSOR_IDENTIFIER") or "UNKNOWN-CPU"
   local drive = os.getenv("SYSTEMDRIVE") or "C:"
   local domain = os.getenv("USERDOMAIN") or ""
   local seed = computer .. "|" .. processor .. "|" .. drive .. "|" .. domain
   return string.upper(simple_hash(seed))
end

local function parse_kv_text(text)
   local t = {}
   if text == nil then return t end
   text = text:gsub("\r\n", "\n"):gsub("\r", "\n")
   for line in (text .. "\n"):gmatch("(.-)\n") do
      line = trim(line)
      if line ~= "" and line:sub(1,1) ~= "#" then
         local k, v = line:match("^([%w_%-]+)%s*=%s*(.*)$")
         if k ~= nil then
            t[string.lower(k)] = trim(v or "")
         end
      end
   end
   return t
end


-- V9.1 numerically-stable local signed-license integrity.
-- Uses only arithmetic well below Lua's exact-integer precision limit.

local function license_secret()
   local a = "B7E"
   local b = "TECH"
   local c = "9K2"
   local d = "SYN"
   local e = "C4Q"
   return a .. "-" .. d .. "-" .. b .. "-" .. e .. "-" .. c
end

local function license_canonical(lic)
   return table.concat({
      tostring(lic.product or ""),
      tostring(lic.customer or ""),
      tostring(lic.status or ""),
      tostring(lic.expires or ""),
      tostring(lic.machine or ""),
      tostring(lic.modules or ""),
      tostring(lic.license_id or ""),
      tostring(lic.login_user or ""),
      tostring(lic.login_pass or "")
   }, "|")
end

local function stable_hash(s, seed, multiplier)
   local mod = 2147483647
   local h = seed or 17
   local m = multiplier or 131
   local i = 1

   while i <= #s do
      local c = string.byte(s, i)
      h = (h * m + c + i) % mod
      i = i + 1
   end

   return string.format("%08X", h)
end

local function sign_license_fields(lic)
   local payload = license_secret() .. "|" .. license_canonical(lic)
   local h1 = stable_hash(payload, 17, 131)
   local h2 = stable_hash(string.reverse(payload) .. "|" .. h1, 97, 137)
   local h3 = stable_hash(h1 .. "|" .. h2 .. "|" .. payload, 193, 149)
   return h1 .. h2 .. h3
end

local function verify_license_signature(lic)
   local supplied = upper(lic.signature or "")
   if supplied == "" then
      return false
   end

   local expected = upper(sign_license_fields(lic))
   return supplied == expected
end

local function default_dev_license_text()
   local lic = {
      product = PRODUCT_ID,
      customer = "BE.TECH DEVELOPMENT",
      status = "ACTIVE",
      expires = "2027-12-31",
      machine = "12DA621C83EBD81A",
      modules = "SYNTEC_EXPORT",
      license_id = "DEV-USER-0001",
      login_user = "admin",
      login_pass = stable_hash("Betech2026!", 257, 157)
   }

   local signature = sign_license_fields(lic)

   return table.concat({
      "# BE.TECH SIGNED LOCAL DEVELOPMENT LICENSE V9.1",
      "product=" .. lic.product,
      "customer=" .. lic.customer,
      "status=" .. lic.status,
      "expires=" .. lic.expires,
      "machine=" .. lic.machine,
      "modules=" .. lic.modules,
      "license_id=" .. lic.license_id,
      "login_user=" .. lic.login_user,
      "login_pass=" .. lic.login_pass,
      "signature=" .. signature
   }, "\r\n")
end

local function ensure_dev_license()
   local p = license_path()
   local f = io.open(p, "rb")
   if f ~= nil then
      f:close()
      return true
   end

   local wf = io.open(p, "wb")
   if wf == nil then
      return false
   end
   wf:write(default_dev_license_text())
   wf:close()
   return true
end

local function read_license_file()
   ensure_dev_license()

   local f = io.open(license_path(), "rb")
   if f == nil then
      return parse_kv_text(default_dev_license_text())
   end
   local data = f:read("*all")
   f:close()
   return parse_kv_text(data)
end

local function parse_expiry_date(s)
   local y, m, d = tostring(s or ""):match("^(%d%d%d%d)%-(%d%d)%-(%d%d)$")
   if y == nil then return nil end
   return os.time({
      year=tonumber(y),
      month=tonumber(m),
      day=tonumber(d),
      hour=23,
      min=59,
      sec=59
   })
end

local function format_expiry(s)
   local y, m, d = tostring(s or ""):match("^(%d%d%d%d)%-(%d%d)%-(%d%d)$")
   if y == nil then return tostring(s or "") end
   return d .. "/" .. m .. "/" .. y
end

local function evaluate_license(lic)
   local result = {
      allowed = false,
      state = "INVALID",
      message = "רישיון לא תקין"
   }

   if lic == nil then
      return result
   end


   if not verify_license_signature(lic) then
      result.state = "BAD_SIGNATURE"
      result.message = "חתימת הרישיון אינה תקינה"
      return result
   end

   if upper(lic.product or "") ~= upper(PRODUCT_ID) then
      result.message = "הרישיון אינו מתאים למוצר זה"
      return result
   end

   if upper(lic.status or "") ~= "ACTIVE" then
      result.state = "INACTIVE"
      result.message = "הרישיון אינו פעיל"
      return result
   end

   local expiry = parse_expiry_date(lic.expires)
   if expiry == nil then
      result.state = "INVALID_DATE"
      result.message = "תאריך הרישיון אינו תקין"
      return result
   end

   if os.time() > expiry then
      result.state = "EXPIRED"
      result.message = "תוקף הרישיון הסתיים"
      return result
   end

   local expected_machine = upper(lic.machine or "")
   local actual_machine = upper(machine_id())

   if expected_machine == "" or expected_machine == "ANY" then
      result.state = "UNBOUND"
      result.message = "הרישיון אינו קשור למחשב"
      return result
   end

   if expected_machine ~= actual_machine then
      result.state = "WRONG_MACHINE"
      result.message = "הרישיון שייך למחשב אחר"
      return result
   end

   result.allowed = true
   result.state = "ACTIVE"
   result.message = "רישיון פעיל ומקושר למחשב"
   return result
end

local function refresh_license()
   g_license = read_license_file()
   g_license.machine_id = machine_id()
   g_license.eval = evaluate_license(g_license)
   return g_license
end

local function license_allows_use(show_message)
   local lic = refresh_license()
   if lic.eval.allowed then
      return true
   end

   if show_message then
      DisplayMessageBox(
         "BE.TECH Licensing\n\n" ..
         lic.eval.message ..
         "\n\nLicense ID: " .. tostring(lic.license_id or "-")
      )
   end
   return false
end


-- =========================
-- V12 MODULAR LICENSING
-- Each licensed feature is enforced independently.
-- =========================

local function normalize_module_name(name)
   return upper(tostring(name or "")):gsub("%-", "_")
end

local function license_has_module(module_name)
   if g_license == nil then
      refresh_license()
   end

   if g_license == nil or g_license.eval == nil or not g_license.eval.allowed then
      return false
   end

   local wanted = normalize_module_name(module_name)
   local raw = tostring(g_license.modules or "")

   for token in string.gmatch(raw, "[^,%s;]+") do
      local mod = normalize_module_name(token)
      if mod == "ALL" or mod == wanted then
         return true
      end
   end

   return false
end

local function license_allows_module(module_name, show_message)
   local lic = refresh_license()

   if not lic.eval.allowed then
      if show_message then
         DisplayMessageBox(
            "BE.TECH Licensing\\n\\n" ..
            lic.eval.message ..
            "\\n\\nLicense ID: " .. tostring(lic.license_id or "-")
         )
      end
      return false
   end

   if license_has_module(module_name) then
      return true
   end

   if show_message then
      DisplayMessageBox(
         "BE.TECH Licensing\\n\\n" ..
         "המודול " .. tostring(module_name) .. " אינו כלול ברישיון זה." ..
         "\\n\\nלקוח: " .. tostring(lic.customer or "-") ..
         "\\nLicense ID: " .. tostring(lic.license_id or "-")
      )
   end

   return false
end

local function licensed_modules_display()
   local raw = tostring((g_license and g_license.modules) or "")
   if trim(raw) == "" then return "-" end
   raw = raw:gsub(",", ", ")
   return raw
end

local function syntec_module_status()
   if g_license == nil or g_license.eval == nil or not g_license.eval.allowed then
      return "LOCKED"
   end
   if license_has_module("SYNTEC_EXPORT") then
      return "ENABLED"
   end
   return "NOT LICENSED"
end


local function module_entitlement_status(module_name)
   if g_license == nil or g_license.eval == nil or not g_license.eval.allowed then
      return "LOCKED"
   end
   if license_has_module(module_name) then
      return "LICENSED"
   end
   return "LOCKED"
end

local function slot_generator_hub_status()
   if module_entitlement_status("SLOT_GENERATOR") == "LICENSED" then
      return "ENABLED"
   end
   return "LOCKED"
end

local function future_tools_hub_status()
   if module_entitlement_status("FUTURE_TOOLS") == "LICENSED" then
      return "LICENSED / RESERVED"
   end
   return "LOCKED"
end


local function cabinet_system_hub_status()
   if module_entitlement_status("CABINET_SYSTEM") == "LICENSED" then
      return "ENABLED"
   end
   return "LOCKED"
end

local function hinge_drill_hub_status()
   if module_entitlement_status("HINGE_DRILL") == "LICENSED" then
      return "ENABLED"
   end
   return "LOCKED"
end

local function license_customer()
   return tostring((g_license and g_license.customer) or "-")
end

local function license_expiry_display()
   return format_expiry((g_license and g_license.expires) or "-")
end

local function license_status_display()
   if g_license == nil or g_license.eval == nil then return "UNKNOWN" end
   if g_license.eval.allowed then return "פעיל" end
   return g_license.eval.message
end



-- =========================
-- V13 ACTIVATION REQUEST
-- Generates a machine-readable request file so Machine ID is never retyped manually.
-- =========================

local function activation_request_path()
   return join_path(g_script_path, "activation_request.txt")
end

local function activation_request_text()
   local lines = {
      "# BE.TECH ACTIVATION REQUEST v13",
      "product=" .. PRODUCT_ID,
      "machine=" .. machine_id(),
      "app_version=" .. APP_VERSION,
      "computer=" .. tostring(os.getenv("COMPUTERNAME") or ""),
      "user_domain=" .. tostring(os.getenv("USERDOMAIN") or "")
   }
   return table.concat(lines, "\r\n")
end

function OnLuaButton_CreateActivationRequest()
   local path = activation_request_path()
   local ok = write_all(path, activation_request_text())

   if ok then
      dialog:UpdateLabelField("ActivationStatus", "נוצר activation_request.txt בתיקיית ה-Gadget")
      DisplayMessageBox(
         "BE.TECH Activation Request\n\n" ..
         "קובץ הבקשה נוצר בהצלחה:\n" ..
         tostring(path) ..
         "\n\nיש לשלוח את activation_request.txt ל-BE.TECH."
      )
   else
      dialog:UpdateLabelField("ActivationStatus", "שגיאה ביצירת קובץ הבקשה")
      DisplayMessageBox("BE.TECH Activation Request\n\nלא ניתן ליצור activation_request.txt")
   end

   return true
end

function OnLuaButton_Login()
   refresh_license()

   if not g_license.eval.allowed then
      dialog:UpdateLabelField("LoginStatus", g_license.eval.message)
      dialog:UpdateLabelField("AuthState", "LOCKED")
      return true
   end

   local user = trim(dialog:GetTextField("LoginUser"))
   local pass = dialog:GetTextField("LoginPass") or ""

   local expected_user = tostring(g_license.login_user or "")
   local expected_pass = upper(tostring(g_license.login_pass or ""))
   local supplied_pass = upper(stable_hash(pass, 257, 157))

   if expected_user ~= "" and user == expected_user and supplied_pass == expected_pass then
      dialog:UpdateLabelField("LoginStatus", "התחברות הצליחה")
      dialog:UpdateLabelField("AuthState", "AUTHORIZED")
   else
      dialog:UpdateLabelField("LoginStatus", "שם משתמש או סיסמה שגויים")
      dialog:UpdateLabelField("AuthState", "LOCKED")
   end

   return true
end

local function save_settings(folder, post_name, drill_tools)
   local data = (folder or "") .. "\n" ..
                (post_name or "") .. "\n" ..
                (drill_tools or "")
   write_all(settings_path(), data)
end

local function load_settings()
   local data = read_all(settings_path())
   if data == nil then return "", "", "21,22,23,24,25,26,27,28,29" end
   data = data:gsub("\r\n", "\n"):gsub("\r", "\n")
   local lines = {}
   for line in (data .. "\n"):gmatch("(.-)\n") do table.insert(lines, line) end
   return trim(lines[1] or ""),
          trim(lines[2] or ""),
          trim(lines[3] or "21,22,23,24,25,26,27,28,29")
end

local function quote_cmd(s)
   s = tostring(s or "")
   s = s:gsub('"', '""')
   return '"' .. s .. '"'
end


local function sanitize_filename(name)
   name = trim(name or "")
   if name == "" then return "AspireJob" end
   name = name:gsub("[\\/:*?\"<>|]", "_")
   name = name:gsub("%.nc$", "")
   return name
end

local function get_job_name()
   local job = VectricJob()
   if job == nil or not job.Exists then
      return "AspireJob"
   end

   local ok, value = pcall(function() return job.Name end)
   if ok and value ~= nil and trim(tostring(value)) ~= "" then
      return sanitize_filename(tostring(value))
   end

   return "AspireJob"
end

local function split_lines(text)
   local lines = {}
   text = text:gsub("\r\n", "\n"):gsub("\r", "\n")
   for line in (text .. "\n"):gmatch("(.-)\n") do
      table.insert(lines, line)
   end
   return lines
end

local function parse_drill_set(s)
   local set = {}
   for token in string.gmatch(s or "", "[^,%s;]+") do
      local n = tonumber(token)
      if n ~= nil then set[n] = true end
   end
   return set
end

local function parse_tool(line)
   local n = upper(line):match("^T(%d+)$")
   if n ~= nil then return tonumber(n) end
   return nil
end

local function is_safety(line)
   local u = upper(line)
   return u == "M35" or u == "M07" or
          u == "M5"  or u == "M05" or
          u == "T0"
end

local function g43_for(line, tool)
   local compact = upper(line):gsub("%s+", "")
   return compact == ("G43H" .. tostring(tool))
end

local function spindle_speed(line)
   local u = upper(line):gsub("%s+", "")
   local s = u:match("^S([%d%.]+)M0?3$")
   if s ~= nil then return s end
   s = u:match("^M0?3S([%d%.]+)$")
   if s ~= nil then return s end
   return nil
end

local function remove_tail_safety(out)
   while #out > 0 and is_safety(out[#out]) do
      table.remove(out)
   end
end

local function convert_nc(text, drill_text)
   local drills = parse_drill_set(drill_text)
   local lines = split_lines(text)
   local out, log, errors = {}, {}, {}
   local mode = nil
   local count_drill, count_atc = 0, 0
   local i = 1

   while i <= #lines do
      local line = lines[i]
      local t = parse_tool(line)

      if t == nil or t == 0 then
         table.insert(out, line)
         i = i + 1
      else
         local g43idx, spidx, speed = nil, nil, nil
         local j = i + 1
         local limit = math.min(i + 4, #lines)

         while j <= limit do
            if g43idx == nil and g43_for(lines[j], t) then
               g43idx = j
            end

            local sp = spindle_speed(lines[j])
            if sp ~= nil then
               spidx = j
               speed = sp
               break
            end

            if parse_tool(lines[j]) ~= nil then break end
            j = j + 1
         end

         if g43idx == nil or spidx == nil or speed == nil then
            table.insert(errors,
               "T" .. tostring(t) ..
               ": לא נמצא בלוק G43/M03 תקין ליד הכלי.")
            table.insert(out, line)
            i = i + 1
         else
            local is_drill = drills[t] == true
            local is_atc = (t >= 1 and t <= 16)

            if (not is_drill) and (not is_atc) then
               table.insert(errors,
                  "T" .. tostring(t) ..
                  ": כלי לא מסווג.")
               table.insert(out, line)
               i = i + 1
            else
               remove_tail_safety(out)

               if is_drill then
                  if mode == nil then
                     table.insert(out, "M35")
                     table.insert(out, "M07")
                     table.insert(out, "M5")
                  elseif mode == "drill" then
                     -- Drill -> Drill: no T0
                  else
                     -- ATC -> Drill Head
                     table.insert(out, "M5")
                     table.insert(out, "M35")
                     table.insert(out, "M07")
                     table.insert(out, "T0")
                  end

                  table.insert(out, "T" .. tostring(t) .. "00")
                  table.insert(out, "S" .. tostring(speed))
                  table.insert(out, "M33")
                  table.insert(out, "M63")

                  table.insert(log,
                     "T" .. tostring(t) ..
                     " -> DRILL | T" .. tostring(t) ..
                     "00 | S" .. tostring(speed) ..
                     " | M33 | M63")

                  count_drill = count_drill + 1
                  mode = "drill"
               else
                  if mode == "drill" then
                     -- Drill Head -> ATC
                     table.insert(out, "T0")
                     table.insert(out, "M35")
                     table.insert(out, "M07")
                     table.insert(out, "M05")
                  else
                     table.insert(out, "M35")
                     table.insert(out, "M07")
                     table.insert(out, "M5")
                  end

                  table.insert(out, "T" .. tostring(t))
                  table.insert(out, "G43 H" .. tostring(t))
                  table.insert(out, "M03 S" .. tostring(speed))

                  table.insert(log,
                     "T" .. tostring(t) ..
                     " -> ATC | G43 H" .. tostring(t) ..
                     " | M03 S" .. tostring(speed))

                  count_atc = count_atc + 1
                  mode = "spindle"
               end

               i = spidx + 1
            end
         end
      end
   end

   table.insert(log, 1,
      "המרה: " .. tostring(count_drill) ..
      " בלוקי קידוח, " .. tostring(count_atc) ..
      " בלוקי ATC.")

   return table.concat(out, "\r\n"),
          table.concat(log, "\r\n"),
          errors
end

local function visit_toolpath_nodes(node, callback, level)
   if node == nil then return end
   node.processchildren = true

   if level > 0 then
      callback(node)
   end

   if node:HasChildren() and node.processchildren then
      local num_children = node:GetNumberOfChildren()
      local i = 0
      while i < num_children do
         local child = node:GetChild(i)
         visit_toolpath_nodes(child, callback, level + 1)
         i = i + 1
      end
   end
end

local function add_all_active_toolpaths(toolpath_saver)
   local manager = ToolpathManager()
   local root_node = manager:GetActiveSideNode()
   local count = 0

   local function add_node(node)
      local tp = node:GetToolpath()
      if tp ~= nil then
         toolpath_saver:AddToolpath(tp)
         count = count + 1
      end
   end

   visit_toolpath_nodes(root_node, add_node, 0)
   return count
end

local function populate_posts(dialog_obj, default_name)
   local saver = ToolpathSaver()

   if default_name == nil or default_name == "" then
      local default_post = saver.DefaultPost
      if default_post ~= nil then default_name = default_post.Name end
   end

   dialog_obj:AddDropDownList("PostNameSelector", default_name or "")

   local n = saver:GetNumPosts()
   local i = 0
   while i < n do
      local post = saver:GetPostAtIndex(i)
      if post ~= nil then
         dialog_obj:AddDropDownListValue("PostNameSelector", post.Name)
      end
      i = i + 1
   end
end

local function direct_export()
   if not license_allows_module("SYNTEC_EXPORT", true) then
      dialog:UpdateLabelField("Status", "BLOCKED - SYNTEC_EXPORT אינו מורשה")
      return false
   end

   local job = VectricJob()
   if job == nil or not job.Exists then
      DisplayMessageBox("אין Job פתוח ב-Aspire.")
      return false
   end

   local post_name = dialog:GetDropDownListValue("PostNameSelector")
   local output_folder = trim(dialog:GetTextField("OutputFolder"))
   local file_name = trim(dialog:GetTextField("OutputName"))
   local drill_tools = trim(dialog:GetTextField("DrillTools"))

   if output_folder == "" then
      DisplayMessageBox("יש להגדיר תיקיית פלט.")
      return false
   end

   if file_name == "" then
      file_name = "AspireJob"
   end

   file_name = file_name:gsub("[\\/:*?\"<>|]", "_")
   file_name = file_name:gsub("%.nc$", "")

   local saver = ToolpathSaver()
   local post = saver:GetPostWithName(post_name)

   if post == nil then
      DisplayMessageBox("לא ניתן לטעון את הפוסט:\n" .. tostring(post_name))
      return false
   end

   local count = add_all_active_toolpaths(saver)
   if count == 0 then
      DisplayMessageBox("לא נמצאו Toolpaths בעבודה הפעילה.")
      return false
   end

   local temp_path = join_path(output_folder, "__BETECH_TEMP__." .. post.Extension)
   local final_path = join_path(output_folder, file_name .. "_SYNTEC.nc")

   local saved = saver:SaveToolpaths(post, temp_path, false)
   if not saved then
      DisplayMessageBox("Aspire לא הצליח לשמור את קובץ הביניים.")
      return false
   end

   local raw, read_err = read_all(temp_path)
   if raw == nil then
      os.remove(temp_path)
      DisplayMessageBox("לא ניתן לקרוא את קובץ הביניים:\n" .. tostring(read_err))
      return false
   end

   local converted, report, errors = convert_nc(raw, drill_tools)

   if #errors > 0 then
      os.remove(temp_path)
      local msg = "בדיקת הבטיחות נכשלה. הקובץ הסופי לא נשמר.\n\n"
      for _, e in ipairs(errors) do msg = msg .. e .. "\n" end
      dialog:UpdateLabelField("Status", "ERROR - לא נוצר קובץ")
      dialog:UpdateLabelField("Report", msg .. "\n" .. report)
      DisplayMessageBox(msg)
      return false
   end

   local ok, err = write_all(final_path, converted)
   os.remove(temp_path)

   if not ok then
      DisplayMessageBox("לא ניתן לשמור קובץ SYNTEC:\n" .. tostring(err))
      return false
   end

   g_last_output = final_path
   dialog:UpdateTextField("OutputFile", final_path)
   dialog:UpdateLabelField("Status",
      "OK - " .. tostring(count) .. " Toolpaths יוצאו ישירות מ-Aspire")
   dialog:UpdateLabelField("Report", report)

   save_settings(output_folder, post_name, drill_tools)

   DisplayMessageBox(
      "הקובץ נוצר ישירות מה-Toolpaths של Aspire.\n\n" ..
      final_path ..
      "\n\nלא נשמר קובץ ביניים.\n" ..
      "יש לבצע Air Cut / Dry Run לפני עבודה על חומר."
   )

   return true
end

function OnDirectoryPicker_SelectFolder(dialog_obj)
   local picked = trim(dialog_obj:GetTextField("OutputFolder"))
   if picked ~= "" then
      local post_name = dialog_obj:GetDropDownListValue("PostNameSelector")
      local drill_tools = trim(dialog_obj:GetTextField("DrillTools"))
      save_settings(picked, post_name, drill_tools)
      dialog_obj:UpdateLabelField("Status", "תיקיית הפלט נבחרה ונשמרה")
   end
   return true
end

function OnLuaButton_UseJobName()
   local name = get_job_name()
   dialog:UpdateTextField("OutputName", name)
   dialog:UpdateLabelField("Status", "שם העבודה נלקח מה-Job הפתוח")
   return true
end

function OnLuaButton_DirectExport()
   return direct_export()
end

function OnLuaButton_OpenFolder()
   local folder = trim(dialog:GetTextField("OutputFolder"))
   if folder == "" and g_last_output ~= "" then
      folder = dirname(g_last_output)
   end

   if folder == "" then
      DisplayMessageBox("לא הוגדרה תיקיית פלט.")
      return true
   end

   os.execute('start "" ' .. quote_cmd(folder))
   return true
end

-- Fallback: old proven conversion mode
function OnLuaButton_ConvertExisting()
   if not license_allows_module("SYNTEC_EXPORT", true) then
      dialog:UpdateLabelField("Status", "BLOCKED - SYNTEC_EXPORT אינו מורשה")
      return true
   end

   local input_path = trim(dialog:GetTextField("InputFile"))
   local drill_tools = trim(dialog:GetTextField("DrillTools"))

   if input_path == "" then
      DisplayMessageBox("יש לבחור קובץ NC.")
      return true
   end

   local raw, err = read_all(input_path)
   if raw == nil then
      DisplayMessageBox("לא ניתן לקרוא קובץ:\n" .. tostring(err))
      return true
   end

   local converted, report, errors = convert_nc(raw, drill_tools)
   if #errors > 0 then
      local msg = "בדיקת הבטיחות נכשלה. הקובץ לא נשמר.\n\n"
      for _, e in ipairs(errors) do msg = msg .. e .. "\n" end
      DisplayMessageBox(msg)
      return true
   end

   local stem = input_path:match("^(.*)%.[^%.\\/]+$") or input_path
   local output_path = stem .. "_SYNTEC.nc"
   local ok, write_err = write_all(output_path, converted)

   if not ok then
      DisplayMessageBox("לא ניתן לשמור:\n" .. tostring(write_err))
      return true
   end

   g_last_output = output_path
   dialog:UpdateTextField("OutputFile", output_path)
   dialog:UpdateLabelField("Status", "OK - קובץ קיים הומר")
   dialog:UpdateLabelField("Report", report)
   DisplayMessageBox("ההמרה הסתיימה:\n" .. output_path)
   return true
end


-- =========================
-- V15 SLOT GENERATOR MODULE
-- Integrated from BE.TECH Slot Generator Pro.
-- The slot module uses a separate HTML_Dialog so the Hub dialog remains intact.
-- =========================

local slot_dialog = nil


Slot_X_Start = 0
Slot_Y_Start = 0
local function round(num)
   return math.floor(num + 0.5)
end

local function get_or_create_layer(layer_manager, layer_name)
   local layer = layer_manager:GetLayerWithName(layer_name)
   if layer == nil then
      layer = layer_manager:CreateLayer(layer_name, true)
   end
   return layer
end

function Slot_DrawRectangle(width,height,x_start,y_start)
   local line = Contour(0.0)
   local current_x = x_start
   local current_y = y_start
   local start_point = Point2D(x_start,y_start)

   line:AppendPoint(start_point)

   for n=1, 4 do
      if n == 1 then
         current_x = current_x + width
      elseif n == 2 then
         current_y = current_y + height
      elseif n == 3 then
         current_x = current_x - width
      elseif n == 4 then
         current_y = current_y - height
      end
      local end_point = Point2D(current_x,current_y)
      line:LineTo(end_point)
   end

   local line_object = CreateCadContour(line)
   return line_object
end

function Slot_DrawLineVertical(x_start,y_start,lineheight)
   local line = Contour(0.0)
   local start_point = Point2D(x_start,y_start)
   line:AppendPoint(start_point)
   line:LineTo(Point2D(x_start, y_start + lineheight))
   return CreateCadContour(line)
end

function Slot_DrawLineHorizontal(x_start,y_start,linewidth)
   local line = Contour(0.0)
   local start_point = Point2D(x_start,y_start)
   line:AppendPoint(start_point)
   line:LineTo(Point2D(x_start + linewidth, y_start))
   return CreateCadContour(line)
end

function Slot_DrawHorizontalLines(layer,width,height,x_start,y_start,LinesGap,SlotSize,Tolerance,Edges)
   local message = ""
   if Edges and (SlotSize > 3) then
      local inner_lines = round((height / (LinesGap + SlotSize)) - 1)
      local distance = (height - (inner_lines * SlotSize) - (SlotSize - 3)) / (inner_lines + 1)
      if math.abs(LinesGap - distance) > Tolerance then
         DisplayMessageBox("Cannot create slots with the current parameters. Try changing gap or tolerance.")
         return false
      end

      local line_width = width + SlotSize
      local current_x = x_start - (SlotSize / 2.0)
      local start_y = y_start - (SlotSize / 2.0)
      local last_y = y_start + height + (SlotSize / 2.0)

      -- first edge line
      layer:AddObject(Slot_DrawLineHorizontal(current_x, start_y, line_width), true)

      -- inner lines
      local current_y = start_y
      for i = 1, inner_lines do
         current_y = current_y + distance + SlotSize
         layer:AddObject(Slot_DrawLineHorizontal(current_x, current_y, line_width), true)
      end

      -- last edge line
      layer:AddObject(Slot_DrawLineHorizontal(current_x, last_y, line_width), true)

      message = string.format("Horizontal slots:\nInner lines: %d\nActual gap: %.3f", inner_lines, distance)
   else
      local lines = round((height / (LinesGap + SlotSize)))
      local distance = (height - (lines * SlotSize)) / (lines + 1)
      if math.abs(LinesGap - distance) > Tolerance then
         DisplayMessageBox("Cannot create slots with the current parameters. Try changing gap or tolerance.")
         return false
      end

      local current_x = x_start - 2.0
      local current_y = y_start + distance + (SlotSize / 2.0)

      for i = 1, lines do
         layer:AddObject(Slot_DrawLineHorizontal(current_x,current_y,width + 4.0), true)
         current_y = current_y + distance + SlotSize
      end

      message = string.format("Horizontal slots:\nLines: %d\nActual gap: %.3f", lines, distance)
   end

   DisplayMessageBox(message)
   return true
end

function Slot_DrawVerticalLines(layer,width,height,x_start,y_start,LinesGap,SlotSize,Tolerance,Edges)
   local message = ""
   if Edges and (SlotSize > 3) then
      local inner_lines = round((width / (LinesGap + SlotSize)) - 1)
      local distance = (width - (inner_lines * SlotSize) - (SlotSize - 3)) / (inner_lines + 1)
      if math.abs(LinesGap - distance) > Tolerance then
         DisplayMessageBox("Cannot create slots with the current parameters. Try changing gap or tolerance.")
         return false
      end

      local line_height = height + SlotSize
      local start_x = x_start - (SlotSize / 2.0)
      local current_y = y_start - (SlotSize / 2.0)
      local last_x = x_start + width + (SlotSize / 2.0)

      -- first edge line
      layer:AddObject(Slot_DrawLineVertical(start_x,current_y,line_height), true)

      -- inner lines
      local current_x = start_x
      for i = 1, inner_lines do
         current_x = current_x + distance + SlotSize
         layer:AddObject(Slot_DrawLineVertical(current_x,current_y,line_height), true)
      end

      -- last edge line
      layer:AddObject(Slot_DrawLineVertical(last_x,current_y,line_height), true)

      message = string.format("Vertical slots:\nInner lines: %d\nActual gap: %.3f", inner_lines, distance)
   else
      local lines = round((width / (LinesGap + SlotSize)))
      local distance = (width - (lines * SlotSize)) / (lines + 1)
      if math.abs(LinesGap - distance) > Tolerance then
         DisplayMessageBox("Cannot create slots with the current parameters. Try changing gap or tolerance.")
         return false
      end

      local current_x = x_start + distance + (SlotSize / 2.0)
      local current_y = y_start - 2.0

      for i = 1, lines do
         layer:AddObject(Slot_DrawLineVertical(current_x,current_y,height + 4.0), true)
         current_x = current_x + distance + SlotSize
      end

      message = string.format("Vertical slots:\nLines: %d\nActual gap: %.3f", lines, distance)
   end

   DisplayMessageBox(message)
   return true
end

function Slot_DrawPattern()
   local Height = slot_dialog:GetDoubleField("HeightInput")
   local Width = slot_dialog:GetDoubleField("WidthInput")
   local LinesGap = slot_dialog:GetDoubleField("LinesGapInput")
   local SlotSize = slot_dialog:GetDoubleField("SlotSizeInput")
   local Num = slot_dialog:GetDoubleField("NumInput")
   local Gap = slot_dialog:GetDoubleField("GapInput")
   local Edges = slot_dialog:GetCheckBox("Edges")
   local Orientation = slot_dialog:GetTextField("OrientationInput")

   local Tolerance = 10
   local DoorsLayerName = "מסגרת"
   local SlotsLayerName = "חריצים"

   local job = VectricJob()
   if not job.Exists then
      DisplayMessageBox("אין Job פתוח")
      return false
   end

   local lm = job.LayerManager
   local DoorsLayer = get_or_create_layer(lm, DoorsLayerName)
   DoorsLayer:SetColor(0, 0, 1)
   local SlotsLayer = get_or_create_layer(lm, SlotsLayerName)
   SlotsLayer:SetColor(0, 1, 0)

   local orig_y = Slot_Y_Start

   for i = 1, Num do
      DoorsLayer:AddObject(Slot_DrawRectangle(Width,Height,Slot_X_Start,Slot_Y_Start), true)

      local ok = true
      if Orientation == "אופקי" or Orientation == "horizontal" then
         ok = Slot_DrawHorizontalLines(SlotsLayer,Width,Height,Slot_X_Start,Slot_Y_Start,LinesGap,SlotSize,Tolerance,Edges)
      else
         ok = Slot_DrawVerticalLines(SlotsLayer,Width,Height,Slot_X_Start,Slot_Y_Start,LinesGap,SlotSize,Tolerance,Edges)
      end

      if not ok then
         return false
      end

      Slot_X_Start = Slot_X_Start + Width + Gap
      Slot_Y_Start = orig_y
   end

   Slot_X_Start = 0
   Slot_Y_Start = Slot_Y_Start + Height + Gap

   job:Refresh2DView()
   return true
end

function OnLuaButton_SlotMakeShape()
   return Slot_DrawPattern()
end

function OnLuaButton_SlotReset()
   Slot_X_Start = 0
   Slot_Y_Start = 0
   local job = VectricJob()
   if job.Exists then
      job:Refresh2DView()
   end
   return true
end

function OnLuaButton_SlotSelect()
   return true
end

function OnLuaButton_SlotClearSelection()
   return true
end


function OnLuaButton_OpenSlotGenerator()
   if not license_allows_module("SLOT_GENERATOR", true) then
      return true
   end

   slot_dialog = HTML_Dialog(
      false,
      "file:" .. g_script_path .. "\\SLOTS.html",
      860,
      900,
      "BE.TECH Slot Generator Pro"
   )

   slot_dialog:AddDoubleField("HeightInput",600)
   slot_dialog:AddDoubleField("WidthInput",400)
   slot_dialog:AddDoubleField("LinesGapInput",40)
   slot_dialog:AddDoubleField("SlotSizeInput",6)
   slot_dialog:AddDoubleField("NumInput",1)
   slot_dialog:AddDoubleField("GapInput",15)
   slot_dialog:AddTextField("OrientationInput","vertical")
   slot_dialog:AddCheckBox("Edges", false)

   slot_dialog:ShowDialog()
   slot_dialog = nil
   return true
end



-- =========================
-- V16 CABINET SYSTEM MODULE
-- Integrated BeTech Cabinet System PRO.
-- Uses its own dialog and script-path state.
-- =========================

local cabinet_dialog = nil
local cabinet_script_path = ""
CAB_X_START = 0
CAB_Y_START = 0

CAB_X_START = 0
CAB_Y_START = 0

local function msg(txt) DisplayMessageBox(tostring(txt)) end

local function draw_rectangle(width, height, x_start, y_start)
  local contour = Contour(0.0)
  contour:AppendPoint(Point2D(x_start, y_start))
  contour:LineTo(Point2D(x_start + width, y_start))
  contour:LineTo(Point2D(x_start + width, y_start + height))
  contour:LineTo(Point2D(x_start, y_start + height))
  contour:LineTo(Point2D(x_start, y_start))
  return CreateCadContour(contour)
end

local function draw_circle(cx, cy, r, segments)
  segments = segments or 28
  local contour = Contour(0.0)
  contour:AppendPoint(Point2D(cx + r, cy))
  for i = 1, segments do
    local a = (2.0 * math.pi * i) / segments
    contour:LineTo(Point2D(cx + math.cos(a) * r, cy + math.sin(a) * r))
  end
  return CreateCadContour(contour)
end

local function draw_trapezoid(top_depth, bottom_depth, height, x, y)
  local max_depth = math.max(top_depth, bottom_depth)
  local contour = Contour(0.0)
  contour:AppendPoint(Point2D(x, y))
  contour:LineTo(Point2D(x + bottom_depth, y))
  contour:LineTo(Point2D(x + top_depth, y + height))
  contour:LineTo(Point2D(x, y + height))
  contour:LineTo(Point2D(x, y))
  return CreateCadContour(contour)
end

local function ensure_layer(job, name, r, g, b)
  local layer = job.LayerManager:GetLayerWithName(name)
  if layer == nil then
    msg("לא נמצאה שכבה בשם: " .. name)
    return nil
  end
  layer:SetColor(r, g, b)
  return layer
end

local function get_parts_layer(job)
  return ensure_layer(job, "01_PARTS_OUTER", 0, 0, 0)
end

local function get_draw_layer(job)
  local layer = ensure_layer(job, "05_DRILL_BLUM_LEGRABOX", 0, 0, 1)
  if layer == nil then layer = ensure_layer(job, "06_DRILL_HINGE_PLATE", 0, 0.5, 0) end
  return layer
end

local function get_hinge_layer(job)
  return ensure_layer(job, "04_DRILL_BLUM_HINGE", 1, 0, 0)
end

local function get_plate_layer(job)
  return ensure_layer(job, "06_DRILL_HINGE_PLATE", 0, 0.5, 0)
end

local function get_assembly_layer(job)
  return ensure_layer(job, "07_BOX_ASSEMBLY", 0.5, 0, 0.5)
end

local function get_clips_layer(job)
  return ensure_layer(job, "08_FRONT_CLIPS", 0.2, 0.6, 0.2)
end

local function get_groove_layer(job)
  return ensure_layer(job, "09_BACK_GROOVE", 0.8, 0.4, 0.0)
end

local function split_numbers(csv_text)
  local values = {}
  if csv_text == nil then return values end
  for token in string.gmatch(csv_text, "([^,]+)") do
    local cleaned = string.gsub(token, "^%s+", "")
    cleaned = string.gsub(cleaned, "%s+$", "")
    local n = tonumber(cleaned)
    if n ~= nil and n > 0 then table.insert(values, n) end
  end
  return values
end

local function add_back_groove(layer, part_x, part_y, part_w, part_h, groove_from_back, groove_width, mirrored)
  if layer == nil then return end
  local groove_x
  if mirrored then
    groove_x = part_x + groove_from_back
  else
    groove_x = part_x + part_w - groove_from_back - groove_width
  end
  layer:AddObject(draw_rectangle(groove_width, part_h + 6.0, groove_x, part_y - 3.0), true)
end

local function add_side_assembly_drilling(layer, side_x, side_y, side_depth, side_height, thickness)
  if layer == nil then return end
  local hole_r = 2.5
  local edge_offset = 45.0
  local x1 = side_x + edge_offset
  local x3 = side_x + side_depth - edge_offset
  local x2 = (x1 + x3) / 2.0
  local y_top = side_y + (thickness / 2.0)
  local y_bottom = side_y + side_height - (thickness / 2.0)
  layer:AddObject(draw_circle(x1, y_top, hole_r, 18), true)
  layer:AddObject(draw_circle(x2, y_top, hole_r, 18), true)
  layer:AddObject(draw_circle(x3, y_top, hole_r, 18), true)
  layer:AddObject(draw_circle(x1, y_bottom, hole_r, 18), true)
  layer:AddObject(draw_circle(x2, y_bottom, hole_r, 18), true)
  layer:AddObject(draw_circle(x3, y_bottom, hole_r, 18), true)
end

local function drawer_count_from_mode(front_mode)
  if front_mode == "2 מגירות" then return 2
  elseif front_mode == "3 מגירות" then return 3
  elseif front_mode == "4 מגירות" then return 4
  else return 0 end
end

local function get_drawer_preset_defaults(preset_name)
  if preset_name == "300+300+147" then
    return {
      front_mode = "3 מגירות",
      height = 760.0,
      depth = 580.0,
      manual_heights_text = "300,300,147",
      nominal_depth = 500.0,
      first_hole_from_bottom = 102.0,
      build_method = "תחתון בין דפנות",
      assembly_method = "Lamello Cabineo 12"
    }
  end
  return nil
end

local function add_side_cabineo_drilling(layer, side_x, side_y, side_depth, side_height, thickness, edge_offset, count_per_joint)
  if layer == nil then return end
  local hole_r = 2.5
  local x_positions = {}
  if count_per_joint <= 2 then
    x_positions = {side_x + edge_offset, side_x + side_depth - edge_offset}
  else
    local x1 = side_x + edge_offset
    local x3 = side_x + side_depth - edge_offset
    local x2 = (x1 + x3) / 2.0
    x_positions = {x1, x2, x3}
  end
  local y_top = side_y + (thickness / 2.0)
  local y_bottom = side_y + side_height - (thickness / 2.0)
  for i = 1, #x_positions do
    layer:AddObject(draw_circle(x_positions[i], y_top, hole_r, 18), true)
    layer:AddObject(draw_circle(x_positions[i], y_bottom, hole_r, 18), true)
  end
end

local function get_drawer_front_heights(front_mode, cabinet_height, gap, small_delta, manual_heights_text, use_manual, top_clearance)
  if use_manual then return split_numbers(manual_heights_text) end
  local heights = {}
  local count = drawer_count_from_mode(front_mode)
  if count <= 0 then return heights end
  local usable_height = cabinet_height - ((count - 1) * gap) - top_clearance
  if count == 2 then
    local h = usable_height / 2.0
    heights = {h, h}
  elseif count == 3 then
    local base = usable_height / 3.0
    local small = base - small_delta
    local large = (usable_height - small) / 2.0
    heights = {large, large, small}
  elseif count == 4 then
    local h = usable_height / 4.0
    heights = {h, h, h, h}
  end
  return heights
end

local function sum_heights(heights)
  local s = 0.0
  for i = 1, #heights do s = s + heights[i] end
  return s
end

local function get_blum_legrabox_hole_positions(nominal_depth)
  if nominal_depth <= 270 then return {37, 224}
  elseif nominal_depth <= 350 then return {37, 256}
  elseif nominal_depth <= 450 then return {37, 256}
  elseif nominal_depth <= 500 then return {37, 224, 256}
  elseif nominal_depth <= 600 then return {37, 224, 256, 320}
  else return {37, 224, 256, 320, 416} end
end

local function get_tandembox_hole_positions(nominal_depth)
  if nominal_depth <= 350 then return {37, 224}
  elseif nominal_depth <= 500 then return {37, 256}
  elseif nominal_depth <= 550 then return {37, 288}
  elseif nominal_depth <= 600 then return {37, 288, 320}
  else return {37, 320, 352} end
end

local function add_drawer_hardware_drilling(layer, x, y_line, depth, nominal_depth, mirrored, hardware)
  if layer == nil then return end
  local hole_r = 2.5
  local edge_clearance = 10.0
  local positions = get_blum_legrabox_hole_positions(nominal_depth)
  if hardware == "Tandembox" then positions = get_tandembox_hole_positions(nominal_depth) end
  for i = 1, #positions do
    local px = positions[i]
    local cx = mirrored and (x + depth - px) or (x + px)
    if cx >= x + edge_clearance and cx <= x + depth - edge_clearance then
      layer:AddObject(draw_circle(cx, y_line, hole_r, 18), true)
    end
  end
end

local function add_drawer_stack_drilling(layer, side_x, side_y, depth, heights, nominal_depth, gap, use_first_hole_from_bottom, first_hole_from_bottom, mirrored, hardware)
  local current_y = side_y
  for i = 1, #heights do
    local y_line = use_first_hole_from_bottom and (current_y + first_hole_from_bottom) or (current_y + (heights[i] / 2.0))
    add_drawer_hardware_drilling(layer, side_x, y_line, depth, nominal_depth, mirrored, hardware)
    current_y = current_y + heights[i] + gap
  end
end

local function add_front_clip_drilling_on_fronts(layer, fronts_x, fronts_y, front_w, heights, gap, clip_from_side, clip_from_top)
  if layer == nil then return end
  local hole_r = 1.5
  local current_y = fronts_y
  for i = 1, #heights do
    local h = heights[i]
    local x_left = fronts_x + clip_from_side
    local x_right = fronts_x + front_w - clip_from_side
    local y_pos = current_y + clip_from_top
    if y_pos < current_y + h then
      layer:AddObject(draw_circle(x_left, y_pos, hole_r, 18), true)
      layer:AddObject(draw_circle(x_right, y_pos, hole_r, 18), true)
    end
    current_y = current_y + h + gap
  end
end

local function add_hinge_cup_drilling(layer, x, y, width, height, side_mode, top_from_door, bottom_from_door, hinge_type)
  if layer == nil then return 0, 0 end
  local cup_r = 17.5
  local cup_center_from_edge = 22.5
  local screw_r = 4.0
  local screw_offset = 22.5
  local screw_shift = 9.0
  if hinge_type == "ClipTop 110" or hinge_type == "Blumotion 110" then
    cup_center_from_edge = 22.5
  end
  local cup_x, screw_x
  if side_mode == "left" then
    cup_x = x + cup_center_from_edge
    screw_x = cup_x + screw_shift
  else
    cup_x = x + width - cup_center_from_edge
    screw_x = cup_x - screw_shift
  end
  local cy1 = y + top_from_door
  local cy2 = y + height - bottom_from_door
  layer:AddObject(draw_circle(cup_x, cy1, cup_r, 28), true)
  layer:AddObject(draw_circle(cup_x, cy2, cup_r, 28), true)
  layer:AddObject(draw_circle(screw_x, cy1 - screw_offset, screw_r, 18), true)
  layer:AddObject(draw_circle(screw_x, cy1 + screw_offset, screw_r, 18), true)
  layer:AddObject(draw_circle(screw_x, cy2 - screw_offset, screw_r, 18), true)
  layer:AddObject(draw_circle(screw_x, cy2 + screw_offset, screw_r, 18), true)
  return cy1, cy2
end

local function add_hinge_plate_drilling(layer, side_x, side_depth, front_setback, plate_line_from_front, plate_hole_pitch, cy1, cy2, mirrored)
  if layer == nil then return end
  local r = 2.5
  local x_line = mirrored and (side_x + side_depth - front_setback - plate_line_from_front) or (side_x + front_setback + plate_line_from_front)
  layer:AddObject(draw_circle(x_line, cy1 - plate_hole_pitch / 2.0, r, 18), true)
  layer:AddObject(draw_circle(x_line, cy1 + plate_hole_pitch / 2.0, r, 18), true)
  layer:AddObject(draw_circle(x_line, cy2 - plate_hole_pitch / 2.0, r, 18), true)
  layer:AddObject(draw_circle(x_line, cy2 + plate_hole_pitch / 2.0, r, 18), true)
end

local function add_shelf_pin_holes(layer, side_x, side_y, side_depth, side_height, front_line, pitch, first_y)
  if layer == nil then return end
  local r = 2.5
  local y = side_y + first_y
  while y <= side_y + side_height - first_y do
    layer:AddObject(draw_circle(side_x + front_line, y, r, 18), true)
    layer:AddObject(draw_circle(side_x + side_depth - front_line, y, r, 18), true)
    y = y + pitch
  end
end

local function add_back_panel(parts_layer, back_x, back_y, back_w, back_h)
  if parts_layer == nil then return end
  parts_layer:AddObject(draw_rectangle(back_w, back_h, back_x, back_y), true)
end

local function add_drawer_box(parts_layer, x, y, clear_w, clear_d, front_h, material_thickness, box_height, bottom_recess)
  if parts_layer == nil then return end
  local side_len = clear_d - 10.0
  local box_w = clear_w - 2.0 * material_thickness
  local part_gap = 10.0
  local x0 = x
  local y0 = y
  -- two sides
  parts_layer:AddObject(draw_rectangle(side_len, box_height, x0, y0), true)
  y0 = y0 + box_height + part_gap
  parts_layer:AddObject(draw_rectangle(side_len, box_height, x0, y0), true)
  -- front and back
  x0 = x + side_len + part_gap
  y0 = y
  parts_layer:AddObject(draw_rectangle(box_w, box_height, x0, y0), true)
  y0 = y0 + box_height + part_gap
  parts_layer:AddObject(draw_rectangle(box_w, box_height, x0, y0), true)
  -- bottom
  x0 = x + side_len + box_w + (part_gap * 2.0)
  y0 = y
  local bottom_w = box_w
  local bottom_d = side_len - bottom_recess
  if bottom_w > 0 and bottom_d > 0 then
    parts_layer:AddObject(draw_rectangle(bottom_w, bottom_d, x0, y0), true)
  end
end

local function next_group_y(height, gap)
  CAB_Y_START = CAB_Y_START + height + gap
end

function build_drawers()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end

  local preset_name = cabinet_dialog:GetTextField("D_Preset")
  local front_mode = cabinet_dialog:GetTextField("D_FrontMode")
  local width = cabinet_dialog:GetDoubleField("D_Width")
  local height = cabinet_dialog:GetDoubleField("D_Height")
  local depth = cabinet_dialog:GetDoubleField("D_Depth")
  local thickness = cabinet_dialog:GetDoubleField("D_Thickness")
  local gap = cabinet_dialog:GetDoubleField("D_Gap")
  local spacing = cabinet_dialog:GetDoubleField("D_Spacing")
  local nominal_depth = cabinet_dialog:GetDoubleField("D_LegraboxDepth")
  local rail_height = cabinet_dialog:GetDoubleField("D_RailHeight")
  local small_delta = cabinet_dialog:GetDoubleField("D_SmallDrawerDelta")
  local manual_heights_text = cabinet_dialog:GetTextField("D_ManualFrontHeights")
  local top_clearance = cabinet_dialog:GetDoubleField("D_TopClearance")
  local first_hole_from_bottom = cabinet_dialog:GetDoubleField("D_FirstHoleFromBottom")
  local back_groove_offset = cabinet_dialog:GetDoubleField("D_BackGrooveOffset")
  local back_groove_width = cabinet_dialog:GetDoubleField("D_BackGrooveWidth")
  local clip_from_side = cabinet_dialog:GetDoubleField("D_ClipFromSide")
  local clip_from_top = cabinet_dialog:GetDoubleField("D_ClipFromTop")
  local add_drawers_enabled = cabinet_dialog:GetCheckBox("D_AddHardwareDrill")
  local add_rails_enabled = cabinet_dialog:GetCheckBox("D_AddRails")
  local add_box_assembly_enabled = cabinet_dialog:GetCheckBox("D_AddBoxAssembly")
  local add_front_clips_enabled = cabinet_dialog:GetCheckBox("D_AddFrontClips")
  local add_back_groove_enabled = cabinet_dialog:GetCheckBox("D_AddBackGroove")
  local use_manual_heights = cabinet_dialog:GetCheckBox("D_UseManualHeights")
  local use_first_hole_from_bottom = cabinet_dialog:GetCheckBox("D_UseFirstHoleFromBottom")
  local add_back_enabled = cabinet_dialog:GetCheckBox("D_AddBack")
  local add_drawer_box_enabled = cabinet_dialog:GetCheckBox("D_AddDrawerBox")
  local use_preset_defaults = cabinet_dialog:GetCheckBox("D_UsePresetDefaults")
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("D_Count") + 0.5))
  local drawer_hardware = cabinet_dialog:GetTextField("D_DrawerHardware")
  local drawer_box_material = cabinet_dialog:GetDoubleField("D_DrawerBoxThickness")
  local build_method = cabinet_dialog:GetTextField("D_BuildMethod")
  local assembly_method = cabinet_dialog:GetTextField("D_AssemblyMethod")
  local front_clearance = cabinet_dialog:GetDoubleField("D_FrontClearance")
  local cabineo_edge_offset = cabinet_dialog:GetDoubleField("D_CabineoEdgeOffset")
  local cabineo_count_per_joint = math.max(2, math.floor(cabinet_dialog:GetDoubleField("D_CabineoCountPerJoint") + 0.5))

  local preset_defaults = get_drawer_preset_defaults(preset_name)
  if preset_defaults ~= nil and use_preset_defaults then
    front_mode = preset_defaults.front_mode
    height = preset_defaults.height
    depth = preset_defaults.depth
    nominal_depth = preset_defaults.nominal_depth
    first_hole_from_bottom = preset_defaults.first_hole_from_bottom
    build_method = preset_defaults.build_method
    assembly_method = preset_defaults.assembly_method
    if use_manual_heights then
      manual_heights_text = preset_defaults.manual_heights_text
    end
  end

  local parts_layer = get_parts_layer(job)
  local draw_layer = get_draw_layer(job)
  local assembly_layer = get_assembly_layer(job)
  local clips_layer = get_clips_layer(job)
  local groove_layer = get_groove_layer(job)
  if parts_layer == nil or draw_layer == nil or assembly_layer == nil or clips_layer == nil or groove_layer == nil then return false end

  local heights = get_drawer_front_heights(front_mode, height, gap, small_delta, manual_heights_text, use_manual_heights, top_clearance)
  if #heights == 0 then msg("לא נקלטו גבהי חזיתות") return false end
  local expected = drawer_count_from_mode(front_mode)
  if use_manual_heights and expected > 0 and #heights ~= expected then
    msg("מספר גבהי החזיתות לא תואם לסוג החזית")
    return false
  end
  if use_manual_heights then
    local total = sum_heights(heights) + ((#heights - 1) * gap) + top_clearance
    if math.abs(total - height) > 1.0 then
      msg("סכום גבהי החזיתות והרווחים לא תואם לגובה הארגז")
      return false
    end
  end

  local inner_width = width - (2.0 * thickness)
  if inner_width <= 0 then msg("הרוחב הפנימי יצא לא תקין") return false end

  local group_gap = 90.0
  for cabinet_idx = 1, count do
    local x = 0
    local y = CAB_Y_START
    local side_height = height
    local bottom_width = inner_width
    if build_method == "תחתון מתחת לדפנות" then
      side_height = height - thickness
      bottom_width = width
    end

    parts_layer:AddObject(draw_rectangle(depth, side_height, x, y), true)
    local left_side_x = x
    local left_side_y = y
    if add_back_groove_enabled then add_back_groove(groove_layer, left_side_x, left_side_y, depth, side_height, back_groove_offset, back_groove_width, false) end
    x = x + depth + spacing

    parts_layer:AddObject(draw_rectangle(depth, side_height, x, y), true)
    local right_side_x = x
    local right_side_y = y
    if add_back_groove_enabled then add_back_groove(groove_layer, right_side_x, right_side_y, depth, side_height, back_groove_offset, back_groove_width, true) end
    x = x + depth + spacing

    parts_layer:AddObject(draw_rectangle(bottom_width, depth, x, y), true)
    x = x + bottom_width + spacing

    if build_method == "תחתון + קושרות" then
      if add_rails_enabled then
        parts_layer:AddObject(draw_rectangle(inner_width, rail_height, x, y), true)
        x = x + inner_width + spacing
        parts_layer:AddObject(draw_rectangle(inner_width, rail_height, x, y), true)
        x = x + inner_width + spacing
      end
    else
      parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
      x = x + inner_width + spacing
      if add_rails_enabled then
        parts_layer:AddObject(draw_rectangle(inner_width, rail_height, x, y), true)
        x = x + inner_width + spacing
        parts_layer:AddObject(draw_rectangle(inner_width, rail_height, x, y), true)
        x = x + inner_width + spacing
      end
    end

    if add_back_enabled then
      local back_h = height - 20.0
      add_back_panel(parts_layer, x, y, inner_width, back_h)
      x = x + inner_width + spacing
    end

    local front_w = width - front_clearance
    local fronts_x = x
    local fronts_y = y
    local current_y = y
    for i = 1, #heights do
      parts_layer:AddObject(draw_rectangle(front_w, heights[i], fronts_x, current_y), true)
      current_y = current_y + heights[i] + gap
    end

    if add_drawers_enabled then
      add_drawer_stack_drilling(draw_layer, left_side_x, left_side_y, depth, heights, nominal_depth, gap, use_first_hole_from_bottom, first_hole_from_bottom, false, drawer_hardware)
      add_drawer_stack_drilling(draw_layer, right_side_x, right_side_y, depth, heights, nominal_depth, gap, use_first_hole_from_bottom, first_hole_from_bottom, true, drawer_hardware)
    end
    if add_box_assembly_enabled then
      if assembly_method == "Lamello Cabineo 12" then
        add_side_cabineo_drilling(assembly_layer, left_side_x, left_side_y, depth, side_height, thickness, cabineo_edge_offset, cabineo_count_per_joint)
        add_side_cabineo_drilling(assembly_layer, right_side_x, right_side_y, depth, side_height, thickness, cabineo_edge_offset, cabineo_count_per_joint)
      else
        add_side_assembly_drilling(assembly_layer, left_side_x, left_side_y, depth, side_height, thickness)
        add_side_assembly_drilling(assembly_layer, right_side_x, right_side_y, depth, side_height, thickness)
      end
    end
    if add_front_clips_enabled then
      add_front_clip_drilling_on_fronts(clips_layer, fronts_x, fronts_y, front_w, heights, gap, clip_from_side, clip_from_top)
    end

    if add_drawer_box_enabled then
      local box_x = fronts_x + front_w + spacing
      local box_y = y
      for i = 1, #heights do
        local box_h = math.max(80.0, math.min(150.0, heights[i] - 40.0))
        add_drawer_box(parts_layer, box_x, box_y, inner_width - 26.0, nominal_depth, heights[i], drawer_box_material, box_h, 20.0)
        box_y = box_y + box_h + 90.0
      end
    end

    next_group_y(height, group_gap)
  end

  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " ארגזי מגירות")
  return true
end

function build_doors()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end

  local front_mode = cabinet_dialog:GetTextField("G_FrontMode")
  local width = cabinet_dialog:GetDoubleField("G_Width")
  local height = cabinet_dialog:GetDoubleField("G_Height")
  local depth = cabinet_dialog:GetDoubleField("G_Depth")
  local thickness = cabinet_dialog:GetDoubleField("G_Thickness")
  local spacing = cabinet_dialog:GetDoubleField("G_Spacing")
  local rail_height = cabinet_dialog:GetDoubleField("G_RailHeight")
  local hinge_top = cabinet_dialog:GetDoubleField("G_HingeTopOffset")
  local hinge_bottom = cabinet_dialog:GetDoubleField("G_HingeBottomOffset")
  local top_clearance = cabinet_dialog:GetDoubleField("G_TopClearance")
  local door_gap_bottom = cabinet_dialog:GetDoubleField("G_DoorBottomGap")
  local plate_line_from_front = cabinet_dialog:GetDoubleField("G_PlateLineFromFront")
  local plate_hole_pitch = cabinet_dialog:GetDoubleField("G_PlateHolePitch")
  local front_setback = cabinet_dialog:GetDoubleField("G_FrontSetback")
  local back_groove_offset = cabinet_dialog:GetDoubleField("G_BackGrooveOffset")
  local back_groove_width = cabinet_dialog:GetDoubleField("G_BackGrooveWidth")
  local add_hinges_enabled = cabinet_dialog:GetCheckBox("G_AddHinges")
  local add_hinge_plates_enabled = cabinet_dialog:GetCheckBox("G_AddHingePlates")
  local add_rails_enabled = cabinet_dialog:GetCheckBox("G_AddRails")
  local add_box_assembly_enabled = cabinet_dialog:GetCheckBox("G_AddBoxAssembly")
  local add_back_groove_enabled = cabinet_dialog:GetCheckBox("G_AddBackGroove")
  local add_back_enabled = cabinet_dialog:GetCheckBox("G_AddBack")
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("G_Count") + 0.5))
  local hinge_type = cabinet_dialog:GetTextField("G_HingeType")

  local parts_layer = get_parts_layer(job)
  local hinge_layer = get_hinge_layer(job)
  local plate_layer = get_plate_layer(job)
  local assembly_layer = get_assembly_layer(job)
  local groove_layer = get_groove_layer(job)
  if parts_layer == nil or hinge_layer == nil or plate_layer == nil or assembly_layer == nil or groove_layer == nil then return false end

  local inner_width = width - (2.0 * thickness)
  if inner_width <= 0 then msg("הרוחב הפנימי יצא לא תקין") return false end

  local group_gap = 90.0
  for cabinet_idx = 1, count do
    local x = 0
    local y = CAB_Y_START
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    local left_side_x = x
    local left_side_y = y
    if add_back_groove_enabled then add_back_groove(groove_layer, left_side_x, left_side_y, depth, height, back_groove_offset, back_groove_width, false) end
    x = x + depth + spacing

    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    local right_side_x = x
    local right_side_y = y
    if add_back_groove_enabled then add_back_groove(groove_layer, right_side_x, right_side_y, depth, height, back_groove_offset, back_groove_width, true) end
    x = x + depth + spacing

    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing

    if add_rails_enabled then
      parts_layer:AddObject(draw_rectangle(inner_width, rail_height, x, y), true)
      x = x + inner_width + spacing
      parts_layer:AddObject(draw_rectangle(inner_width, rail_height, x, y), true)
      x = x + inner_width + spacing
    end

    if add_back_enabled then
      add_back_panel(parts_layer, x, y, inner_width, height - 20.0)
      x = x + inner_width + spacing
    end

    local door_y = y + top_clearance
    local door_h = height - top_clearance - door_gap_bottom

    if front_mode == "דלת אחת" then
      local door_w = width - 4.0
      parts_layer:AddObject(draw_rectangle(door_w, door_h, x, door_y), true)
      if add_hinges_enabled then
        local cy1, cy2 = add_hinge_cup_drilling(hinge_layer, x, door_y, door_w, door_h, "left", hinge_top, hinge_bottom, hinge_type)
        if add_hinge_plates_enabled then add_hinge_plate_drilling(plate_layer, left_side_x, depth, front_setback, plate_line_from_front, plate_hole_pitch, cy1, cy2, false) end
      end
    elseif front_mode == "שתי דלתות" then
      local door_w = (width - 7.0) / 2.0
      parts_layer:AddObject(draw_rectangle(door_w, door_h, x, door_y), true)
      if add_hinges_enabled then
        local cy1_l, cy2_l = add_hinge_cup_drilling(hinge_layer, x, door_y, door_w, door_h, "left", hinge_top, hinge_bottom, hinge_type)
        if add_hinge_plates_enabled then add_hinge_plate_drilling(plate_layer, left_side_x, depth, front_setback, plate_line_from_front, plate_hole_pitch, cy1_l, cy2_l, false) end
      end
      x = x + door_w + spacing
      parts_layer:AddObject(draw_rectangle(door_w, door_h, x, door_y), true)
      if add_hinges_enabled then
        local cy1_r, cy2_r = add_hinge_cup_drilling(hinge_layer, x, door_y, door_w, door_h, "right", hinge_top, hinge_bottom, hinge_type)
        if add_hinge_plates_enabled then add_hinge_plate_drilling(plate_layer, right_side_x, depth, front_setback, plate_line_from_front, plate_hole_pitch, cy1_r, cy2_r, true) end
      end
    else
      msg("סוג חזית לא נתמך. השתמשי ב: דלת אחת / שתי דלתות")
      return false
    end

    if add_box_assembly_enabled then
      add_side_assembly_drilling(assembly_layer, left_side_x, left_side_y, depth, height, thickness)
      add_side_assembly_drilling(assembly_layer, right_side_x, right_side_y, depth, height, thickness)
    end

    next_group_y(height, group_gap)
  end

  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " ארגזי דלתות")
  return true
end

function build_door_shelves()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end
  local width = cabinet_dialog:GetDoubleField("DS_Width")
  local height = cabinet_dialog:GetDoubleField("DS_Height")
  local depth = cabinet_dialog:GetDoubleField("DS_Depth")
  local thickness = cabinet_dialog:GetDoubleField("DS_Thickness")
  local shelf_count = math.max(0, math.floor(cabinet_dialog:GetDoubleField("DS_ShelfCount") + 0.5))
  local shelf_line = cabinet_dialog:GetDoubleField("DS_ShelfLine")
  local shelf_pitch = cabinet_dialog:GetDoubleField("DS_ShelfPitch")
  local first_y = cabinet_dialog:GetDoubleField("DS_FirstHoleY")
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("DS_Count") + 0.5))
  local add_holes = cabinet_dialog:GetCheckBox("DS_AddShelfHoles")
  local add_back = cabinet_dialog:GetCheckBox("DS_AddBack")
  local hinge_type = cabinet_dialog:GetTextField("DS_HingeType")
  local parts_layer = get_parts_layer(job)
  local drill_layer = get_draw_layer(job)
  local hinge_layer = get_hinge_layer(job)
  local plate_layer = get_plate_layer(job)
  local groove_layer = get_groove_layer(job)
  if parts_layer == nil or drill_layer == nil or hinge_layer == nil or plate_layer == nil or groove_layer == nil then return false end
  local inner_width = width - (2.0 * thickness)
  local spacing = 20.0
  local group_gap = 90.0
  for idx = 1, count do
    local x = 0
    local y = CAB_Y_START
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    add_back_groove(groove_layer, x, y, depth, height, 10.0, 6.0, false)
    if add_holes then add_shelf_pin_holes(drill_layer, x, y, depth, height, shelf_line, shelf_pitch, first_y) end
    local left_x = x
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    add_back_groove(groove_layer, x, y, depth, height, 10.0, 6.0, true)
    if add_holes then add_shelf_pin_holes(drill_layer, x, y, depth, height, shelf_line, shelf_pitch, first_y) end
    local right_x = x
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    if add_back then
      add_back_panel(parts_layer, x, y, inner_width, height - 20.0)
      x = x + inner_width + spacing
    end
    for s = 1, shelf_count do
      parts_layer:AddObject(draw_rectangle(inner_width, depth - 20.0, x, y + (s - 1) * 60.0), true)
    end
    x = x + inner_width + spacing
    local door_h = height - 7.0
    local door_w = (width - 7.0) / 2.0
    parts_layer:AddObject(draw_rectangle(door_w, door_h, x, y + 7.0), true)
    local cy1, cy2 = add_hinge_cup_drilling(hinge_layer, x, y + 7.0, door_w, door_h, "left", 100.0, 100.0, hinge_type)
    add_hinge_plate_drilling(plate_layer, left_x, depth, 0.0, 37.0, 32.0, cy1, cy2, false)
    x = x + door_w + spacing
    parts_layer:AddObject(draw_rectangle(door_w, door_h, x, y + 7.0), true)
    local cy3, cy4 = add_hinge_cup_drilling(hinge_layer, x, y + 7.0, door_w, door_h, "right", 100.0, 100.0, hinge_type)
    add_hinge_plate_drilling(plate_layer, right_x, depth, 0.0, 37.0, 32.0, cy3, cy4, true)

    next_group_y(height, group_gap)
  end
  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " ארגזי דלתות + מידוף")
  return true
end

function build_sink_cabinet()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end
  local width = cabinet_dialog:GetDoubleField("S_Width")
  local height = cabinet_dialog:GetDoubleField("S_Height")
  local depth = cabinet_dialog:GetDoubleField("S_Depth")
  local thickness = cabinet_dialog:GetDoubleField("S_Thickness")
  local rail_h = cabinet_dialog:GetDoubleField("S_RailHeight")
  local drawer_h = cabinet_dialog:GetDoubleField("S_InternalDrawerHeight")
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("S_Count") + 0.5))
  local add_internal = cabinet_dialog:GetCheckBox("S_AddInternalDrawer")
  local add_back = cabinet_dialog:GetCheckBox("S_AddBack")
  local drawer_hardware = cabinet_dialog:GetTextField("S_DrawerHardware")
  local parts_layer = get_parts_layer(job)
  local draw_layer = get_draw_layer(job)
  if parts_layer == nil or draw_layer == nil then return false end
  local inner_width = width - (2.0 * thickness)
  local spacing = 20.0
  local group_gap = 90.0
  for idx=1,count do
    local x = 0
    local y = CAB_Y_START
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, rail_h, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, rail_h, x, y), true)
    x = x + inner_width + spacing
    if add_back then
      add_back_panel(parts_layer, x, y, inner_width, height - 20.0)
      x = x + inner_width + spacing
    end
    if add_internal then
      parts_layer:AddObject(draw_rectangle(width - 3.0, drawer_h, x, y), true)
      add_drawer_box(parts_layer, x + width + spacing, y, inner_width - 26.0, depth - 20.0, drawer_h, thickness, math.max(80.0, drawer_h - 20.0), 20.0)
      add_drawer_hardware_drilling(draw_layer, 0.0, y + drawer_h / 2.0, depth, depth - 20.0, false, drawer_hardware)
    end
    next_group_y(height, group_gap)
  end
  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " ארגזי כיור")
  return true
end

function build_hob_cabinet()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end
  local width = cabinet_dialog:GetDoubleField("H_Width")
  local height = cabinet_dialog:GetDoubleField("H_Height")
  local top_depth = cabinet_dialog:GetDoubleField("H_TopDepth")
  local bottom_depth = cabinet_dialog:GetDoubleField("H_BottomDepth")
  local thickness = cabinet_dialog:GetDoubleField("H_Thickness")
  local drawer_h = cabinet_dialog:GetDoubleField("H_BottomDrawerHeight")
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("H_Count") + 0.5))
  local add_bottom_drawer = cabinet_dialog:GetCheckBox("H_AddBottomDrawer")
  local add_back = cabinet_dialog:GetCheckBox("H_AddBack")
  local parts_layer = get_parts_layer(job)
  if parts_layer == nil then return false end
  local inner_width = width - (2.0 * thickness)
  local spacing = 20.0
  local group_gap = 90.0
  for idx=1,count do
    local x = 0
    local y = CAB_Y_START
    parts_layer:AddObject(draw_trapezoid(top_depth, bottom_depth, height, x, y), true)
    x = x + math.max(top_depth, bottom_depth) + spacing
    parts_layer:AddObject(draw_trapezoid(top_depth, bottom_depth, height, x, y), true)
    x = x + math.max(top_depth, bottom_depth) + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, bottom_depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, top_depth, x, y), true)
    x = x + inner_width + spacing
    if add_back then
      add_back_panel(parts_layer, x, y, inner_width, height - 20.0)
      x = x + inner_width + spacing
    end
    if add_bottom_drawer then
      parts_layer:AddObject(draw_rectangle(width - 3.0, drawer_h, x, y), true)
      add_drawer_box(parts_layer, x + width + spacing, y, inner_width - 26.0, bottom_depth - 20.0, drawer_h, thickness, math.max(80.0, drawer_h - 20.0), 20.0)
    end
    next_group_y(height, group_gap)
  end
  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " ארגזי כיריים")
  return true
end

function build_builtin_cabinet()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end
  local width = cabinet_dialog:GetDoubleField("B_Width")
  local height = cabinet_dialog:GetDoubleField("B_Height")
  local depth = cabinet_dialog:GetDoubleField("B_Depth")
  local thickness = cabinet_dialog:GetDoubleField("B_Thickness")
  local cfg = cabinet_dialog:GetTextField("B_DrawerConfig")
  local micro = cabinet_dialog:GetTextField("B_MicroType")
  local top_shelf_h = cabinet_dialog:GetDoubleField("B_TopShelfHeight")
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("B_Count") + 0.5))
  local add_back = cabinet_dialog:GetCheckBox("B_AddBack")
  local parts_layer = get_parts_layer(job)
  if parts_layer == nil then return false end
  local inner_width = width - (2.0 * thickness)
  local spacing = 20.0
  local group_gap = 120.0
  local oven_open_h = 585.0
  local micro_h = 390.0
  if micro == "אינטגרלי" then micro_h = 500.0 end
  for idx=1,count do
    local x = 0
    local y = CAB_Y_START
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true) -- top
    x = x + inner_width + spacing
    if add_back then
      add_back_panel(parts_layer, x, y, inner_width, height - 20.0)
      x = x + inner_width + spacing
    end
    -- fronts / spacers
    if cfg == "300+300" then
      parts_layer:AddObject(draw_rectangle(width - 3.0, 300.0, x, y), true)
      parts_layer:AddObject(draw_rectangle(width - 3.0, 300.0, x, y + 303.0), true)
    elseif cfg == "150+300" then
      parts_layer:AddObject(draw_rectangle(width - 3.0, 150.0, x, y), true)
      parts_layer:AddObject(draw_rectangle(width - 3.0, 300.0, x, y + 153.0), true)
    else
      parts_layer:AddObject(draw_rectangle(width - 3.0, 300.0, x, y), true)
    end
    x = x + width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, top_shelf_h, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, oven_open_h, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, micro_h, x, y), true)

    next_group_y(height, group_gap)
  end
  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " ארגזי בילדאין")
  return true
end

function build_pantry_cabinet()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end
  local width = cabinet_dialog:GetDoubleField("P_Width")
  local height = cabinet_dialog:GetDoubleField("P_Height")
  local depth = cabinet_dialog:GetDoubleField("P_Depth")
  local thickness = cabinet_dialog:GetDoubleField("P_Thickness")
  local drawer_count = math.max(0, math.floor(cabinet_dialog:GetDoubleField("P_DrawerCount") + 0.5))
  local shelf_count = math.max(0, math.floor(cabinet_dialog:GetDoubleField("P_ShelfCount") + 0.5))
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("P_Count") + 0.5))
  local add_back = cabinet_dialog:GetCheckBox("P_AddBack")
  local parts_layer = get_parts_layer(job)
  if parts_layer == nil then return false end
  local inner_width = width - (2.0 * thickness)
  local spacing = 20.0
  local group_gap = 120.0
  for idx=1,count do
    local x = 0
    local y = CAB_Y_START
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    if add_back then
      add_back_panel(parts_layer, x, y, inner_width, height - 20.0)
      x = x + inner_width + spacing
    end
    local part_y = y
    for s=1,shelf_count do
      parts_layer:AddObject(draw_rectangle(inner_width, depth - 20.0, x, part_y), true)
      part_y = part_y + 60.0
    end
    x = x + inner_width + spacing
    part_y = y
    for d=1,drawer_count do
      parts_layer:AddObject(draw_rectangle(width - 3.0, 150.0, x, part_y), true)
      part_y = part_y + 153.0
    end
    next_group_y(height, group_gap)
  end
  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " ארגזי מזווה")
  return true
end

function build_upper_cabinet()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end
  local width = cabinet_dialog:GetDoubleField("U_Width")
  local height = cabinet_dialog:GetDoubleField("U_Height")
  local depth = cabinet_dialog:GetDoubleField("U_Depth")
  local thickness = cabinet_dialog:GetDoubleField("U_Thickness")
  local flap_count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("U_FlapCount") + 0.5))
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("U_Count") + 0.5))
  local add_back = cabinet_dialog:GetCheckBox("U_AddBack")
  local parts_layer = get_parts_layer(job)
  if parts_layer == nil then return false end
  local inner_width = width - (2.0 * thickness)
  local spacing = 20.0
  local group_gap = 90.0
  for idx=1,count do
    local x = 0
    local y = CAB_Y_START
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    if add_back then
      add_back_panel(parts_layer, x, y, inner_width, height - 20.0)
      x = x + inner_width + spacing
    end
    local flap_h = height / flap_count
    local fy = y
    for f=1,flap_count do
      parts_layer:AddObject(draw_rectangle(width - 3.0, flap_h - 3.0, x, fy), true)
      fy = fy + flap_h
    end
    next_group_y(height, group_gap)
  end
  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " ארונות עליונים")
  return true
end

function build_laundry_cabinet()
  local job = VectricJob()
  if not job.Exists then msg("אין Job פתוח") return false end
  local width = cabinet_dialog:GetDoubleField("L_Width")
  local height = cabinet_dialog:GetDoubleField("L_Height")
  local depth = cabinet_dialog:GetDoubleField("L_Depth")
  local thickness = cabinet_dialog:GetDoubleField("L_Thickness")
  local top_shelves = math.max(0, math.floor(cabinet_dialog:GetDoubleField("L_TopShelves") + 0.5))
  local count = math.max(1, math.floor(cabinet_dialog:GetDoubleField("L_Count") + 0.5))
  local add_back = cabinet_dialog:GetCheckBox("L_AddBack")
  local parts_layer = get_parts_layer(job)
  if parts_layer == nil then return false end
  local inner_width = width - (2.0 * thickness)
  local spacing = 20.0
  local group_gap = 120.0
  for idx=1,count do
    local x = 0
    local y = CAB_Y_START
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(depth, height, x, y), true)
    x = x + depth + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    parts_layer:AddObject(draw_rectangle(inner_width, depth, x, y), true)
    x = x + inner_width + spacing
    if add_back then
      add_back_panel(parts_layer, x, y, inner_width, height - 20.0)
      x = x + inner_width + spacing
    end
    local sy = y
    for s=1,top_shelves do
      parts_layer:AddObject(draw_rectangle(inner_width, depth - 20.0, x, sy), true)
      sy = sy + 60.0
    end
    next_group_y(height, group_gap)
  end
  job:Refresh2DView()
  msg("נוצרו " .. tostring(count) .. " נישות כביסה")
  return true
end

-- cabinet_dialog openers
local function open_dialog(file_name, title, width, height)
  cabinet_dialog = HTML_Dialog(false, "file:" .. cabinet_script_path .. "/" .. file_name, width, height, title)
  return cabinet_dialog
end

local function open_drawers_dialog()
  cabinet_dialog = open_dialog("drawers.html", "BeTech - ארגז מגירות", 680, 1080)
  cabinet_dialog:AddTextField("D_Preset", "300+300+147")
  cabinet_dialog:AddTextField("D_FrontMode", "3 מגירות")
  cabinet_dialog:AddDoubleField("D_Width", 800.0)
  cabinet_dialog:AddDoubleField("D_Height", 760.0)
  cabinet_dialog:AddDoubleField("D_Depth", 580.0)
  cabinet_dialog:AddDoubleField("D_Thickness", 16.7)
  cabinet_dialog:AddDoubleField("D_Gap", 3.0)
  cabinet_dialog:AddDoubleField("D_Spacing", 20.0)
  cabinet_dialog:AddDoubleField("D_LegraboxDepth", 500.0)
  cabinet_dialog:AddDoubleField("D_RailHeight", 80.0)
  cabinet_dialog:AddDoubleField("D_SmallDrawerDelta", 104.0)
  cabinet_dialog:AddTextField("D_ManualFrontHeights", "300,300,147")
  cabinet_dialog:AddDoubleField("D_TopClearance", 7.0)
  cabinet_dialog:AddDoubleField("D_FirstHoleFromBottom", 102.0)
  cabinet_dialog:AddDoubleField("D_BackGrooveOffset", 10.0)
  cabinet_dialog:AddDoubleField("D_BackGrooveWidth", 6.0)
  cabinet_dialog:AddDoubleField("D_ClipFromSide", 37.0)
  cabinet_dialog:AddDoubleField("D_ClipFromTop", 37.0)
  cabinet_dialog:AddTextField("D_DrawerHardware", "Legrabox")
  cabinet_dialog:AddTextField("D_BuildMethod", "תחתון בין דפנות")
  cabinet_dialog:AddTextField("D_AssemblyMethod", "Lamello Cabineo 12")
  cabinet_dialog:AddDoubleField("D_FrontClearance", 3.0)
  cabinet_dialog:AddDoubleField("D_CabineoEdgeOffset", 37.0)
  cabinet_dialog:AddDoubleField("D_CabineoCountPerJoint", 2.0)
  cabinet_dialog:AddDoubleField("D_DrawerBoxThickness", 16.0)
  cabinet_dialog:AddDoubleField("D_Count", 1.0)
  cabinet_dialog:AddCheckBox("D_AddHardwareDrill", true)
  cabinet_dialog:AddCheckBox("D_AddRails", false)
  cabinet_dialog:AddCheckBox("D_AddBoxAssembly", true)
  cabinet_dialog:AddCheckBox("D_AddFrontClips", true)
  cabinet_dialog:AddCheckBox("D_AddBackGroove", true)
  cabinet_dialog:AddCheckBox("D_UseManualHeights", true)
  cabinet_dialog:AddCheckBox("D_UsePresetDefaults", true)
  cabinet_dialog:AddCheckBox("D_UseFirstHoleFromBottom", false)
  cabinet_dialog:AddCheckBox("D_AddBack", true)
  cabinet_dialog:AddCheckBox("D_AddDrawerBox", true)
  cabinet_dialog:ShowDialog()
  return true
end

local function open_doors_dialog()
  cabinet_dialog = open_dialog("doors.html", "BeTech - ארגז דלתות", 640, 980)
  cabinet_dialog:AddTextField("G_FrontMode", "שתי דלתות")
  cabinet_dialog:AddDoubleField("G_Width", 800.0)
  cabinet_dialog:AddDoubleField("G_Height", 760.0)
  cabinet_dialog:AddDoubleField("G_Depth", 580.0)
  cabinet_dialog:AddDoubleField("G_Thickness", 16.7)
  cabinet_dialog:AddDoubleField("G_Spacing", 20.0)
  cabinet_dialog:AddDoubleField("G_RailHeight", 80.0)
  cabinet_dialog:AddDoubleField("G_TopClearance", 7.0)
  cabinet_dialog:AddDoubleField("G_DoorBottomGap", 0.0)
  cabinet_dialog:AddDoubleField("G_HingeTopOffset", 100.0)
  cabinet_dialog:AddDoubleField("G_HingeBottomOffset", 100.0)
  cabinet_dialog:AddDoubleField("G_PlateLineFromFront", 37.0)
  cabinet_dialog:AddDoubleField("G_PlateHolePitch", 32.0)
  cabinet_dialog:AddDoubleField("G_FrontSetback", 0.0)
  cabinet_dialog:AddDoubleField("G_BackGrooveOffset", 10.0)
  cabinet_dialog:AddDoubleField("G_BackGrooveWidth", 6.0)
  cabinet_dialog:AddTextField("G_HingeType", "Blumotion 110")
  cabinet_dialog:AddDoubleField("G_Count", 1.0)
  cabinet_dialog:AddCheckBox("G_AddHinges", true)
  cabinet_dialog:AddCheckBox("G_AddHingePlates", true)
  cabinet_dialog:AddCheckBox("G_AddRails", false)
  cabinet_dialog:AddCheckBox("G_AddBoxAssembly", true)
  cabinet_dialog:AddCheckBox("G_AddBackGroove", true)
  cabinet_dialog:AddCheckBox("G_AddBack", true)
  cabinet_dialog:ShowDialog()
  return true
end

local function open_door_shelves_dialog()
  cabinet_dialog = open_dialog("door_shelves.html", "BeTech - דלתות + מידוף", 640, 900)
  cabinet_dialog:AddDoubleField("DS_Width", 800.0)
  cabinet_dialog:AddDoubleField("DS_Height", 760.0)
  cabinet_dialog:AddDoubleField("DS_Depth", 580.0)
  cabinet_dialog:AddDoubleField("DS_Thickness", 16.7)
  cabinet_dialog:AddDoubleField("DS_ShelfCount", 3.0)
  cabinet_dialog:AddDoubleField("DS_ShelfLine", 37.0)
  cabinet_dialog:AddDoubleField("DS_ShelfPitch", 32.0)
  cabinet_dialog:AddDoubleField("DS_FirstHoleY", 64.0)
  cabinet_dialog:AddTextField("DS_HingeType", "Blumotion 110")
  cabinet_dialog:AddDoubleField("DS_Count", 1.0)
  cabinet_dialog:AddCheckBox("DS_AddShelfHoles", true)
  cabinet_dialog:AddCheckBox("DS_AddBack", true)
  cabinet_dialog:ShowDialog()
  return true
end

local function open_sink_dialog()
  cabinet_dialog = open_dialog("sink.html", "BeTech - ארגז כיור", 640, 820)
  cabinet_dialog:AddDoubleField("S_Width", 800.0)
  cabinet_dialog:AddDoubleField("S_Height", 760.0)
  cabinet_dialog:AddDoubleField("S_Depth", 580.0)
  cabinet_dialog:AddDoubleField("S_Thickness", 16.7)
  cabinet_dialog:AddDoubleField("S_RailHeight", 80.0)
  cabinet_dialog:AddDoubleField("S_InternalDrawerHeight", 150.0)
  cabinet_dialog:AddTextField("S_DrawerHardware", "Legrabox")
  cabinet_dialog:AddDoubleField("S_Count", 1.0)
  cabinet_dialog:AddCheckBox("S_AddInternalDrawer", true)
  cabinet_dialog:AddCheckBox("S_AddBack", true)
  cabinet_dialog:ShowDialog()
  return true
end

local function open_hob_dialog()
  cabinet_dialog = open_dialog("hob.html", "BeTech - ארגז כיריים", 640, 780)
  cabinet_dialog:AddDoubleField("H_Width", 900.0)
  cabinet_dialog:AddDoubleField("H_Height", 760.0)
  cabinet_dialog:AddDoubleField("H_TopDepth", 500.0)
  cabinet_dialog:AddDoubleField("H_BottomDepth", 580.0)
  cabinet_dialog:AddDoubleField("H_Thickness", 16.7)
  cabinet_dialog:AddDoubleField("H_BottomDrawerHeight", 150.0)
  cabinet_dialog:AddDoubleField("H_Count", 1.0)
  cabinet_dialog:AddCheckBox("H_AddBottomDrawer", true)
  cabinet_dialog:AddCheckBox("H_AddBack", true)
  cabinet_dialog:ShowDialog()
  return true
end

local function open_builtin_dialog()
  cabinet_dialog = open_dialog("builtin.html", "BeTech - ארגז בילדאין", 640, 860)
  cabinet_dialog:AddDoubleField("B_Width", 600.0)
  cabinet_dialog:AddDoubleField("B_Height", 2140.0)
  cabinet_dialog:AddDoubleField("B_Depth", 580.0)
  cabinet_dialog:AddDoubleField("B_Thickness", 16.7)
  cabinet_dialog:AddTextField("B_DrawerConfig", "300+300")
  cabinet_dialog:AddTextField("B_MicroType", "רגיל")
  cabinet_dialog:AddDoubleField("B_TopShelfHeight", 350.0)
  cabinet_dialog:AddDoubleField("B_Count", 1.0)
  cabinet_dialog:AddCheckBox("B_AddBack", true)
  cabinet_dialog:ShowDialog()
  return true
end

local function open_pantry_dialog()
  cabinet_dialog = open_dialog("pantry.html", "BeTech - ארגז מזווה", 640, 780)
  cabinet_dialog:AddDoubleField("P_Width", 600.0)
  cabinet_dialog:AddDoubleField("P_Height", 2140.0)
  cabinet_dialog:AddDoubleField("P_Depth", 580.0)
  cabinet_dialog:AddDoubleField("P_Thickness", 16.7)
  cabinet_dialog:AddDoubleField("P_DrawerCount", 2.0)
  cabinet_dialog:AddDoubleField("P_ShelfCount", 3.0)
  cabinet_dialog:AddDoubleField("P_Count", 1.0)
  cabinet_dialog:AddCheckBox("P_AddBack", true)
  cabinet_dialog:ShowDialog()
  return true
end

local function open_upper_dialog()
  cabinet_dialog = open_dialog("upper.html", "BeTech - ארון עליון קלפה", 640, 760)
  cabinet_dialog:AddDoubleField("U_Width", 800.0)
  cabinet_dialog:AddDoubleField("U_Height", 720.0)
  cabinet_dialog:AddDoubleField("U_Depth", 300.0)
  cabinet_dialog:AddDoubleField("U_Thickness", 16.7)
  cabinet_dialog:AddDoubleField("U_FlapCount", 1.0)
  cabinet_dialog:AddDoubleField("U_Count", 1.0)
  cabinet_dialog:AddCheckBox("U_AddBack", true)
  cabinet_dialog:ShowDialog()
  return true
end

local function open_laundry_dialog()
  cabinet_dialog = open_dialog("laundry.html", "BeTech - נישת כביסה", 640, 760)
  cabinet_dialog:AddDoubleField("L_Width", 1300.0)
  cabinet_dialog:AddDoubleField("L_Height", 2200.0)
  cabinet_dialog:AddDoubleField("L_Depth", 700.0)
  cabinet_dialog:AddDoubleField("L_Thickness", 16.7)
  cabinet_dialog:AddDoubleField("L_TopShelves", 2.0)
  cabinet_dialog:AddDoubleField("L_Count", 1.0)
  cabinet_dialog:AddCheckBox("L_AddBack", true)
  cabinet_dialog:ShowDialog()
  return true
end

-- Open handlers
function OnLuaButton_OpenDrawers(dialog_window) return open_drawers_dialog() end
function OnLuaButton_LuaButton_OpenDrawers(dialog_window) return open_drawers_dialog() end
function OnLuaButton_OpenDoors(dialog_window) return open_doors_dialog() end
function OnLuaButton_LuaButton_OpenDoors(dialog_window) return open_doors_dialog() end
function OnLuaButton_OpenDoorShelves(dialog_window) return open_door_shelves_dialog() end
function OnLuaButton_LuaButton_OpenDoorShelves(dialog_window) return open_door_shelves_dialog() end
function OnLuaButton_OpenSink(dialog_window) return open_sink_dialog() end
function OnLuaButton_LuaButton_OpenSink(dialog_window) return open_sink_dialog() end
function OnLuaButton_OpenHob(dialog_window) return open_hob_dialog() end
function OnLuaButton_LuaButton_OpenHob(dialog_window) return open_hob_dialog() end
function OnLuaButton_OpenBuiltin(dialog_window) return open_builtin_dialog() end
function OnLuaButton_LuaButton_OpenBuiltin(dialog_window) return open_builtin_dialog() end
function OnLuaButton_OpenPantry(dialog_window) return open_pantry_dialog() end
function OnLuaButton_LuaButton_OpenPantry(dialog_window) return open_pantry_dialog() end
function OnLuaButton_OpenUpper(dialog_window) return open_upper_dialog() end
function OnLuaButton_LuaButton_OpenUpper(dialog_window) return open_upper_dialog() end
function OnLuaButton_OpenLaundry(dialog_window) return open_laundry_dialog() end
function OnLuaButton_LuaButton_OpenLaundry(dialog_window) return open_laundry_dialog() end

-- Generate handlers
function OnLuaButton_GenerateDrawers(dialog_window) return build_drawers() end
function OnLuaButton_LuaButton_GenerateDrawers(dialog_window) return build_drawers() end
function OnLuaButton_GenerateDoors(dialog_window) return build_doors() end
function OnLuaButton_LuaButton_GenerateDoors(dialog_window) return build_doors() end
function OnLuaButton_GenerateDoorShelves(dialog_window) return build_door_shelves() end
function OnLuaButton_LuaButton_GenerateDoorShelves(dialog_window) return build_door_shelves() end
function OnLuaButton_GenerateSink(dialog_window) return build_sink_cabinet() end
function OnLuaButton_LuaButton_GenerateSink(dialog_window) return build_sink_cabinet() end
function OnLuaButton_GenerateHob(dialog_window) return build_hob_cabinet() end
function OnLuaButton_LuaButton_GenerateHob(dialog_window) return build_hob_cabinet() end
function OnLuaButton_GenerateBuiltin(dialog_window) return build_builtin_cabinet() end
function OnLuaButton_LuaButton_GenerateBuiltin(dialog_window) return build_builtin_cabinet() end
function OnLuaButton_GeneratePantry(dialog_window) return build_pantry_cabinet() end
function OnLuaButton_LuaButton_GeneratePantry(dialog_window) return build_pantry_cabinet() end
function OnLuaButton_GenerateUpper(dialog_window) return build_upper_cabinet() end
function OnLuaButton_LuaButton_GenerateUpper(dialog_window) return build_upper_cabinet() end
function OnLuaButton_GenerateLaundry(dialog_window) return build_laundry_cabinet() end
function OnLuaButton_LuaButton_GenerateLaundry(dialog_window) return build_laundry_cabinet() end


function OnLuaButton_OpenCabinetSystem()
   if not license_allows_module("CABINET_SYSTEM", true) then
      return true
   end

   cabinet_script_path = string.gsub(g_script_path, "\\", "/")
   cabinet_dialog = HTML_Dialog(
      false,
      "file:" .. cabinet_script_path .. "/main_menu.html",
      560,
      760,
      "BeTech Cabinet System PRO"
   )
   cabinet_dialog:ShowDialog()
   cabinet_dialog = nil
   return true
end



-- =========================
-- V17 HINGE DRILL MODULE
-- Integrated from BE.TECH Hinge Drill Generator beta4.
-- =========================
local hinge_dialog = nil


local function Hinge_msg(txt)
  DisplayMessageBox(tostring(txt))
end

local function Hinge_draw_circle(cx, cy, r, segments)
  segments = segments or 36
  local contour = Contour(0.0)
  contour:AppendPoint(Point2D(cx + r, cy))
  for i = 1, segments do
    local a = (2.0 * math.pi * i) / segments
    contour:LineTo(Point2D(cx + math.cos(a) * r, cy + math.sin(a) * r))
  end
  return CreateCadContour(contour)
end

local function Hinge_draw_rectangle(width, height, x, y)
  local contour = Contour(0.0)
  contour:AppendPoint(Point2D(x, y))
  contour:LineTo(Point2D(x + width, y))
  contour:LineTo(Point2D(x + width, y + height))
  contour:LineTo(Point2D(x, y + height))
  contour:LineTo(Point2D(x, y))
  return CreateCadContour(contour)
end

local function Hinge_ensure_layer(job, name, r, g, b)
  local layer = job.LayerManager:GetLayerWithName(name)
  if layer == nil then
    layer = job.LayerManager:CreateLayer(name, true)
  end
  layer:SetColor(r, g, b)
  return layer
end

-- יצירת חורי הציר
local function Hinge_add_hinge(layer, cx, cy, cup_dia, screw_dia, screw_offset_y, screw_offset_x, make_cups, make_screws)

  if make_cups then
    layer:AddObject(Hinge_draw_circle(cx, cy, cup_dia / 2.0, 36), true)
  end

  if make_screws then
    local sx = cx + screw_offset_x
    layer:AddObject(Hinge_draw_circle(sx, cy - screw_offset_y, screw_dia / 2.0, 24), true)
    layer:AddObject(Hinge_draw_circle(sx, cy + screw_offset_y, screw_dia / 2.0, 24), true)
  end
end

local function Hinge_auto_hinge_positions(door_h, top_off, bottom_off, hinge_count)
  local ys = {}
  if hinge_count <= 2 then
    ys = {top_off, door_h - bottom_off}
  elseif hinge_count == 3 then
    ys = {top_off, door_h / 2.0, door_h - bottom_off}
  else
    ys = {top_off, door_h / 3.0, (door_h / 3.0) * 2.0, door_h - bottom_off}
  end
  return ys
end

local function Hinge_build()

  local job = VectricJob()
  if not job.Exists then
    Hinge_msg("אין Job פתוח")
    return false
  end

  local door_h = hinge_dialog:GetDoubleField("DoorHeight")
  local door_w = hinge_dialog:GetDoubleField("DoorWidth")
  local top_off = hinge_dialog:GetDoubleField("TopOffset")
  local bottom_off = hinge_dialog:GetDoubleField("BottomOffset")

  local cup_dia = hinge_dialog:GetDoubleField("CupDiameter")
  local tb = hinge_dialog:GetDoubleField("TB")

  local hinge_count = hinge_dialog:GetDoubleField("HingeCount")
  local side = hinge_dialog:GetTextField("Side")

  local screw_dia = hinge_dialog:GetDoubleField("ScrewDiameter")
  local screw_offset_y = hinge_dialog:GetDoubleField("ScrewOffsetY")

  local x_start = hinge_dialog:GetDoubleField("XStart")
  local y_start = hinge_dialog:GetDoubleField("YStart")

  local make_outline = hinge_dialog:GetCheckBox("MakeOutline")
  local make_cups = hinge_dialog:GetCheckBox("MakeCups")
  local make_screws = hinge_dialog:GetCheckBox("MakeScrews")

  if hinge_count < 2 then hinge_count = 2 end
  if hinge_count > 4 then hinge_count = 4 end

  local parts = Hinge_ensure_layer(job,"01_PARTS_OUTER",0,0,0)
  local drill = Hinge_ensure_layer(job,"04_DRILL_BLUM_HINGE",1,0,0)

  if make_outline then
    parts:AddObject(Hinge_draw_rectangle(door_w,door_h,x_start,y_start),true)
  end

  local cx = x_start + tb + (cup_dia/2)
  local screw_offset_x = 9

  if side == "ימין" or side == "right" then
    cx = x_start + door_w - tb - (cup_dia/2)
    screw_offset_x = -9
  end

  local ys = Hinge_auto_hinge_positions(door_h,top_off,bottom_off,hinge_count)

  for i=1,#ys do
    Hinge_add_hinge(drill,cx,y_start+ys[i],cup_dia,screw_dia,screw_offset_y,screw_offset_x,make_cups,make_screws)
  end

  job:Refresh2DView()

  Hinge_msg("קידוחי הצירים נוצרו בהצלחה")
  return true
end

function OnLuaButton_HingeGenerate()
  return Hinge_build()
end

function OnLuaButton_HingeReset()
  return true
end


function OnLuaButton_OpenHingeDrill()
   if not license_allows_module("HINGE_DRILL", true) then
      return true
   end

   hinge_dialog = HTML_Dialog(
      false,
      "file:" .. g_script_path .. "\\hinge_beta4_he.html",
      560,
      900,
      "מחולל קידוחי צירים BE.TECH"
   )

   hinge_dialog:AddDoubleField("DoorHeight",720)
   hinge_dialog:AddDoubleField("DoorWidth",450)
   hinge_dialog:AddDoubleField("TopOffset",100)
   hinge_dialog:AddDoubleField("BottomOffset",100)
   hinge_dialog:AddDoubleField("CupDiameter",35)
   hinge_dialog:AddDoubleField("TB",5)
   hinge_dialog:AddDoubleField("ScrewDiameter",5)
   hinge_dialog:AddDoubleField("ScrewOffsetY",22.5)
   hinge_dialog:AddDoubleField("HingeCount",2)
   hinge_dialog:AddTextField("Side","שמאל")
   hinge_dialog:AddDoubleField("XStart",0)
   hinge_dialog:AddDoubleField("YStart",0)
   hinge_dialog:AddCheckBox("MakeOutline",true)
   hinge_dialog:AddCheckBox("MakeCups",true)
   hinge_dialog:AddCheckBox("MakeScrews",true)

   hinge_dialog:ShowDialog()
   hinge_dialog = nil
   return true
end



-- =========================
-- V17.4 ONLINE UPDATE CHECK
-- HTTPS manifest fetch via Windows curl.exe
-- Safe fallback to local manifest.
-- No automatic update installation in this version.
-- =========================

local function update_manifest_path()
   return join_path(g_script_path, "update_manifest.txt")
end

local function update_config_path()
   return join_path(g_script_path, "update_config.txt")
end

local function update_online_cache_path()
   return join_path(g_script_path, "update_manifest_online.txt")
end

local function parse_version_parts(v)
   local a,b,c = string.match(tostring(v or ""), "^(%d+)%.(%d+)%.(%d+)$")
   if a == nil then
      a,b = string.match(tostring(v or ""), "^(%d+)%.(%d+)$")
      c = "0"
   end
   return tonumber(a) or 0, tonumber(b) or 0, tonumber(c) or 0
end

local function compare_versions(a, b)
   local a1,a2,a3 = parse_version_parts(a)
   local b1,b2,b3 = parse_version_parts(b)

   if a1 < b1 then return -1 elseif a1 > b1 then return 1 end
   if a2 < b2 then return -1 elseif a2 > b2 then return 1 end
   if a3 < b3 then return -1 elseif a3 > b3 then return 1 end
   return 0
end

local function read_manifest_file(path)
   local f = io.open(path, "rb")
   if f == nil then return nil, "NOT_FOUND" end

   local txt = f:read("*all") or ""
   f:close()

   if trim(txt) == "" then return nil, "EMPTY" end

   local data = parse_kv_text(txt)

   if trim(tostring(data.latest_version or "")) == "" then
      return nil, "INVALID_VERSION"
   end

   local product = trim(tostring(data.product or ""))
   if product ~= "" and product ~= "BETECH-CNC-TOOLS-HUB" then
      return nil, "WRONG_PRODUCT"
   end

   return data, "OK"
end

local function read_update_manifest()
   return read_manifest_file(update_manifest_path())
end

local function read_online_update_config()
   local f = io.open(update_config_path(), "rb")
   if f == nil then return nil, "NO_CONFIG" end
   local txt = f:read("*all") or ""
   f:close()

   local cfg = parse_kv_text(txt)
   local url = trim(tostring(cfg.manifest_url or ""))

   if url == "" then return nil, "NO_URL" end
   if string.sub(string.lower(url), 1, 8) ~= "https://" then
      return nil, "HTTPS_REQUIRED"
   end

   return cfg, "OK"
end

local function delete_file_silent(path)
   if path == nil or path == "" then return end
   pcall(function() os.remove(path) end)
end

local function shell_quote_windows(s)
   local v = tostring(s or "")
   v = string.gsub(v, '"', '""')
   return '"' .. v .. '"'
end

local function fetch_online_manifest()
   local cfg, cfg_state = read_online_update_config()

   if cfg_state ~= "OK" then
      return nil, cfg_state
   end

   local url = trim(tostring(cfg.manifest_url or ""))
   local cache = update_online_cache_path()

   delete_file_silent(cache)

   -- curl.exe is called explicitly. This avoids PowerShell alias ambiguity.
   -- -f  fail on HTTP errors
   -- -sS quiet progress but show errors
   -- -L  follow redirects
   -- connect timeout 5 sec / overall timeout 12 sec
   local cmd =
      'curl.exe --fail --silent --show-error --location ' ..
      '--connect-timeout 5 --max-time 12 ' ..
      '--output ' .. shell_quote_windows(cache) .. ' ' ..
      shell_quote_windows(url)

   pcall(function()
      os.execute(cmd)
   end)

   local manifest, state = read_manifest_file(cache)
   if manifest == nil then
      delete_file_silent(cache)
      return nil, "FETCH_FAILED_" .. tostring(state)
   end

   return manifest, "OK"
end

local function status_from_manifest(manifest)
   if manifest == nil then return "NO MANIFEST" end

   local latest = tostring(manifest.latest_version or APP_VERSION)
   local cmp = compare_versions(APP_VERSION, latest)

   if cmp < 0 then return "UPDATE AVAILABLE: " .. latest end
   if cmp > 0 then return "DEV BUILD: " .. APP_VERSION end
   return "UP TO DATE"
end

local function update_status_text()
   local manifest = read_update_manifest()
   if manifest == nil then return "NO LOCAL MANIFEST" end
   return status_from_manifest(manifest)
end

local function update_latest_version()
   local manifest = read_update_manifest()
   if manifest == nil then return "-" end
   return tostring(manifest.latest_version or "-")
end

local function update_channel()
   local manifest = read_update_manifest()
   if manifest == nil then return "stable" end
   local c = trim(tostring(manifest.channel or "stable"))
   if c == "" then c = "stable" end
   return c
end

local function update_source_text()
   return "LOCAL"
end

local function update_dialog_from_manifest(manifest, source_name)
   local latest = tostring(manifest.latest_version or APP_VERSION)
   local channel = tostring(manifest.channel or "stable")
   local status = status_from_manifest(manifest)

   dialog:UpdateLabelField("LatestVersion", latest)
   dialog:UpdateLabelField("UpdateChannel", channel)
   dialog:UpdateLabelField("UpdateStatus", status)
   dialog:UpdateLabelField("HubUpdateStatus", status)
   dialog:UpdateLabelField("UpdateSource", source_name)
end

local function show_update_result(manifest, source_name)
   local latest = tostring(manifest.latest_version or APP_VERSION)
   local channel = tostring(manifest.channel or "stable")
   local notes = tostring(manifest.notes or "")
   local mandatory = string.lower(trim(tostring(manifest.mandatory or "false")))
   local cmp = compare_versions(APP_VERSION, latest)

   update_dialog_from_manifest(manifest, source_name)

   if cmp < 0 then
      local message =
         "BE.TECH Online Update\n\n" ..
         "קיימת גרסה חדשה.\n\n" ..
         "Installed: " .. APP_VERSION ..
         "\nLatest: " .. latest ..
         "\nChannel: " .. channel ..
         "\nSource: " .. source_name

      if mandatory == "true" then
         message = message .. "\nRequired: YES"
      end

      if trim(notes) ~= "" then
         message = message .. "\n\nNotes:\n" .. notes
      end

      DisplayMessageBox(message)

   elseif cmp > 0 then
      DisplayMessageBox(
         "BE.TECH Online Update\n\n" ..
         "הגרסה המותקנת חדשה יותר מהגרסה שפורסמה.\n\n" ..
         "Installed: " .. APP_VERSION ..
         "\nPublished: " .. latest ..
         "\nSource: " .. source_name
      )
   else
      DisplayMessageBox(
         "BE.TECH Online Update\n\n" ..
         "המערכת מעודכנת.\n\n" ..
         "Version: " .. APP_VERSION ..
         "\nSource: " .. source_name
      )
   end
end


local function updates_folder_path()
   return join_path(g_script_path, "updates")
end

local function sanitize_filename_part(s)
   local v = tostring(s or "")
   v = string.gsub(v, "[^%w%._%-]", "_")
   if trim(v) == "" then v = "update" end
   return v
end

local function ensure_updates_folder()
   local folder = updates_folder_path()
   local cmd = 'cmd.exe /C if not exist ' .. shell_quote_windows(folder) ..
               ' mkdir ' .. shell_quote_windows(folder)
   pcall(function() os.execute(cmd) end)
   return folder
end

local function file_size(path)
   local f = io.open(path, "rb")
   if f == nil then return 0 end
   local size = f:seek("end") or 0
   f:close()
   return size
end

local function download_update_package(manifest)
   if manifest == nil then return nil, "NO_MANIFEST" end

   local latest = trim(tostring(manifest.latest_version or ""))
   local url = trim(tostring(manifest.download_url or ""))

   if latest == "" then return nil, "NO_VERSION" end
   if url == "" then return nil, "NO_DOWNLOAD_URL" end

   if string.sub(string.lower(url), 1, 8) ~= "https://" then
      return nil, "HTTPS_REQUIRED"
   end

   if compare_versions(APP_VERSION, latest) >= 0 then
      return nil, "NO_NEWER_VERSION"
   end

   local folder = ensure_updates_folder()
   local filename = "BE.TECH_CNC_Tools_Hub_" .. sanitize_filename_part(latest) .. ".zip"
   local target = join_path(folder, filename)

   delete_file_silent(target)

   local cmd =
      'curl.exe --fail --silent --show-error --location ' ..
      '--connect-timeout 8 --max-time 120 ' ..
      '--output ' .. shell_quote_windows(target) .. ' ' ..
      shell_quote_windows(url)

   pcall(function() os.execute(cmd) end)

   local size = file_size(target)
   if size <= 0 then
      delete_file_silent(target)
      return nil, "DOWNLOAD_FAILED"
   end

   return target, "OK"
end

function OnLuaButton_DownloadUpdate()
   local manifest, state = fetch_online_manifest()

   if manifest == nil then
      dialog:UpdateLabelField("DownloadStatus", "FAILED")
      DisplayMessageBox(
         "BE.TECH Update Download\n\n" ..
         "לא ניתן לקרוא את ה-Manifest האונליין.\n\n" ..
         "Reason: " .. tostring(state or "-")
      )
      return true
   end

   local latest = tostring(manifest.latest_version or APP_VERSION)

   if compare_versions(APP_VERSION, latest) >= 0 then
      dialog:UpdateLabelField("DownloadStatus", "UP TO DATE")
      DisplayMessageBox(
         "BE.TECH Update Download\n\n" ..
         "אין גרסה חדשה להורדה.\n\n" ..
         "Installed: " .. APP_VERSION ..
         "\nLatest: " .. latest
      )
      return true
   end

   local target, dl_state = download_update_package(manifest)

   if target == nil then
      dialog:UpdateLabelField("DownloadStatus", tostring(dl_state or "FAILED"))

      local text =
         "BE.TECH Update Download\n\n" ..
         "לא ניתן להוריד את העדכון.\n\n" ..
         "Latest: " .. latest ..
         "\nReason: " .. tostring(dl_state or "-")

      if dl_state == "NO_DOWNLOAD_URL" then
         text = text ..
            "\n\nהגרסה החדשה מזוהה, אבל download_url עדיין לא הוגדר ב-Manifest."
      end

      DisplayMessageBox(text)
      return true
   end

   dialog:UpdateLabelField("DownloadStatus", "DOWNLOADED")
   dialog:UpdateLabelField("DownloadedFile", target)

   DisplayMessageBox(
      "BE.TECH Update Download\n\n" ..
      "העדכון הורד בהצלחה.\n\n" ..
      "Version: " .. latest ..
      "\nSaved to:\n" .. target ..
      "\n\nהקובץ לא הותקן אוטומטית."
   )

   return true
end


-- =========================
-- V17.6 SAFE UPDATE INSTALLER
-- Prepare -> validate -> backup -> install after Aspire closes
-- =========================

local function staging_root_path()
   return join_path(updates_folder_path(), "staging")
end

local function backups_root_path()
   return join_path(g_script_path, "backups")
end

local function prepared_info_path()
   return join_path(updates_folder_path(), "prepared_update.txt")
end

local function installer_script_path()
   return join_path(updates_folder_path(), "install_prepared_update.cmd")
end

local function read_text_file(path)
   local f = io.open(path, "rb")
   if f == nil then return nil end
   local txt = f:read("*all") or ""
   f:close()
   return txt
end

local function file_exists(path)
   local f = io.open(path, "rb")
   if f == nil then return false end
   f:close()
   return true
end

local function directory_reset(path)
   local cmd =
      'cmd.exe /C if exist ' .. shell_quote_windows(path) ..
      ' rmdir /S /Q ' .. shell_quote_windows(path) ..
      ' & mkdir ' .. shell_quote_windows(path)
   pcall(function() os.execute(cmd) end)
end

local function expected_download_path(version)
   local filename = "BE.TECH_CNC_Tools_Hub_" .. sanitize_filename_part(version) .. ".zip"
   return join_path(updates_folder_path(), filename)
end

local function extract_zip_to_staging(zip_path)
   local staging = staging_root_path()
   directory_reset(staging)

   local cmd =
      'tar.exe -xf ' .. shell_quote_windows(zip_path) ..
      ' -C ' .. shell_quote_windows(staging)

   pcall(function() os.execute(cmd) end)

   local payload = join_path(staging, "BE.TECH CNC Tools Hub")
   local main_lua = join_path(payload, "BE.TECH CNC Tools Hub.lua")

   if not file_exists(main_lua) then
      payload = staging
      main_lua = join_path(payload, "BE.TECH CNC Tools Hub.lua")
   end

   if not file_exists(main_lua) then
      return nil, "MAIN_LUA_MISSING"
   end

   return payload, "OK"
end

local function package_version_from_payload(payload)
   local txt = read_text_file(join_path(payload, "BE.TECH CNC Tools Hub.lua"))
   if txt == nil then return nil end
   return string.match(txt, 'local APP_VERSION = "([%d%.]+)"')
end

local function validate_update_payload(payload, expected_version)
   local required = {
      "BE.TECH CNC Tools Hub.lua",
      "SyntecConverter.html",
      "logo.png",
      "SLOTS.html",
      "main_menu.html",
      "hinge_beta4_he.html"
   }

   for i = 1, #required do
      if not file_exists(join_path(payload, required[i])) then
         return false, "MISSING_" .. required[i]
      end
   end

   local package_version = package_version_from_payload(payload)
   if package_version == nil then
      return false, "VERSION_NOT_FOUND"
   end

   if tostring(package_version) ~= tostring(expected_version) then
      return false, "VERSION_MISMATCH_" .. tostring(package_version)
   end

   return true, "OK"
end

local function write_prepared_info(version, zip_path, payload_path)
   local f = io.open(prepared_info_path(), "wb")
   if f == nil then return false end
   f:write("version=" .. tostring(version) .. "\r\n")
   f:write("zip=" .. tostring(zip_path) .. "\r\n")
   f:write("payload=" .. tostring(payload_path) .. "\r\n")
   f:close()
   return true
end

local function read_prepared_info()
   local txt = read_text_file(prepared_info_path())
   if txt == nil then return nil end
   return parse_kv_text(txt)
end

function OnLuaButton_PrepareUpdate()
   local manifest, state = fetch_online_manifest()

   if manifest == nil then
      dialog:UpdateLabelField("PrepareStatus", "FAILED")
      DisplayMessageBox(
         "BE.TECH Prepare Update\n\n" ..
         "לא ניתן לקרוא את ה-Manifest האונליין.\n\n" ..
         "Reason: " .. tostring(state or "-")
      )
      return true
   end

   local latest = trim(tostring(manifest.latest_version or ""))

   if latest == "" or compare_versions(APP_VERSION, latest) >= 0 then
      dialog:UpdateLabelField("PrepareStatus", "NO UPDATE")
      DisplayMessageBox(
         "BE.TECH Prepare Update\n\n" ..
         "אין עדכון חדש להכנה.\n\n" ..
         "Installed: " .. APP_VERSION ..
         "\nLatest: " .. tostring(latest)
      )
      return true
   end

   local zip_path = expected_download_path(latest)

   if not file_exists(zip_path) then
      dialog:UpdateLabelField("PrepareStatus", "DOWNLOAD FIRST")
      DisplayMessageBox(
         "BE.TECH Prepare Update\n\n" ..
         "קובץ העדכון עדיין לא הורד.\n\n" ..
         "לחץ קודם על 'הורד עדכון'."
      )
      return true
   end

   local payload, extract_state = extract_zip_to_staging(zip_path)
   if payload == nil then
      dialog:UpdateLabelField("PrepareStatus", tostring(extract_state))
      DisplayMessageBox(
         "BE.TECH Prepare Update\n\n" ..
         "לא ניתן להכין את חבילת העדכון.\n\n" ..
         "Reason: " .. tostring(extract_state)
      )
      return true
   end

   local valid, validation_state = validate_update_payload(payload, latest)
   if not valid then
      dialog:UpdateLabelField("PrepareStatus", "INVALID PACKAGE")
      DisplayMessageBox(
         "BE.TECH Prepare Update\n\n" ..
         "חבילת העדכון נכשלה בבדיקת בטיחות.\n\n" ..
         "Reason: " .. tostring(validation_state) ..
         "\n\nלא הוחלף אף קובץ פעיל."
      )
      return true
   end

   if not write_prepared_info(latest, zip_path, payload) then
      dialog:UpdateLabelField("PrepareStatus", "INFO WRITE FAILED")
      DisplayMessageBox("BE.TECH Prepare Update\n\nלא ניתן לשמור את נתוני ההכנה.")
      return true
   end

   dialog:UpdateLabelField("PrepareStatus", "READY TO INSTALL")
   dialog:UpdateLabelField("PreparedVersion", latest)

   DisplayMessageBox(
      "BE.TECH Prepare Update\n\n" ..
      "העדכון נבדק והוא מוכן להתקנה.\n\n" ..
      "Version: " .. latest ..
      "\n\nעדיין לא הוחלף אף קובץ."
   )

   return true
end

local function create_install_script(version, payload)
   local backup = join_path(backups_root_path(), "before_" .. sanitize_filename_part(version))
   local script = installer_script_path()
   local result = join_path(updates_folder_path(), "install_result.txt")

   local f = io.open(script, "wb")
   if f == nil then return nil, "SCRIPT_CREATE_FAILED" end

   f:write("@echo off\r\n")
   f:write("setlocal\r\n")
   f:write("set \"GADGET=" .. g_script_path .. "\"\r\n")
   f:write("set \"PAYLOAD=" .. payload .. "\"\r\n")
   f:write("set \"BACKUP=" .. backup .. "\"\r\n")
   f:write("set \"RESULT=" .. result .. "\"\r\n")
   f:write("echo WAITING>\"%RESULT%\"\r\n")
   f:write(":WAIT_ASPIRE\r\n")
   f:write("tasklist /FI \"IMAGENAME eq Aspire.exe\" 2>NUL | find /I \"Aspire.exe\" >NUL\r\n")
   f:write("if not errorlevel 1 (\r\n")
   f:write("  timeout /T 2 /NOBREAK >NUL\r\n")
   f:write("  goto WAIT_ASPIRE\r\n")
   f:write(")\r\n")
   f:write("if exist \"%BACKUP%\" rmdir /S /Q \"%BACKUP%\"\r\n")
   f:write("mkdir \"%BACKUP%\" >NUL 2>&1\r\n")
   f:write("robocopy \"%GADGET%\" \"%BACKUP%\" /E /R:1 /W:1 /XD updates backups /XF license.dat update_config.txt >NUL\r\n")
   f:write("if errorlevel 8 (\r\n")
   f:write("  echo BACKUP_FAILED>\"%RESULT%\"\r\n")
   f:write("  exit /B 1\r\n")
   f:write(")\r\n")
   f:write("robocopy \"%PAYLOAD%\" \"%GADGET%\" /E /R:1 /W:1 /XD updates backups /XF license.dat update_config.txt >NUL\r\n")
   f:write("if errorlevel 8 (\r\n")
   f:write("  echo INSTALL_FAILED>\"%RESULT%\"\r\n")
   f:write("  exit /B 1\r\n")
   f:write(")\r\n")
   f:write("echo INSTALLED_" .. tostring(version) .. ">\"%RESULT%\"\r\n")
   f:write("exit /B 0\r\n")
   f:close()

   return script, "OK"
end

function OnLuaButton_InstallPreparedUpdate()
   local info = read_prepared_info()

   if info == nil then
      dialog:UpdateLabelField("InstallStatus", "PREPARE FIRST")
      DisplayMessageBox(
         "BE.TECH Safe Install\n\n" ..
         "אין עדכון מוכן להתקנה.\n\n" ..
         "לחץ קודם על 'הכן עדכון'."
      )
      return true
   end

   local version = trim(tostring(info.version or ""))
   local payload = trim(tostring(info.payload or ""))

   if version == "" or payload == "" then
      dialog:UpdateLabelField("InstallStatus", "INVALID PREPARED DATA")
      DisplayMessageBox("BE.TECH Safe Install\n\nנתוני העדכון המוכן אינם תקינים.")
      return true
   end

   local valid, validation_state = validate_update_payload(payload, version)
   if not valid then
      dialog:UpdateLabelField("InstallStatus", "VALIDATION FAILED")
      DisplayMessageBox(
         "BE.TECH Safe Install\n\n" ..
         "בדיקת החבילה נכשלה שוב לפני ההתקנה.\n\n" ..
         "Reason: " .. tostring(validation_state)
      )
      return true
   end

   local script, script_state = create_install_script(version, payload)
   if script == nil then
      dialog:UpdateLabelField("InstallStatus", tostring(script_state))
      DisplayMessageBox("BE.TECH Safe Install\n\nלא ניתן ליצור מתקין בטוח.")
      return true
   end

   local launch =
      'cmd.exe /C start "" /MIN cmd.exe /C ' .. shell_quote_windows(script)

   pcall(function() os.execute(launch) end)

   dialog:UpdateLabelField("InstallStatus", "WAITING FOR ASPIRE TO CLOSE")

   DisplayMessageBox(
      "BE.TECH Safe Install\n\n" ..
      "המתקין מוכן ופועל ברקע.\n\n" ..
      "כעת סגור את Aspire.\n" ..
      "לאחר הסגירה המערכת:\n" ..
      "1. תגבה את הגרסה הנוכחית\n" ..
      "2. תשמור את license.dat ואת update_config.txt\n" ..
      "3. תתקין את Version " .. version .. "\n\n" ..
      "לאחר מספר שניות פתח מחדש את Aspire."
   )

   return true
end

function OnLuaButton_CheckUpdates()
   local online_manifest, online_state = fetch_online_manifest()

   if online_manifest ~= nil then
      show_update_result(online_manifest, "ONLINE")
      return true
   end

   local local_manifest, local_state = read_update_manifest()

   if local_manifest ~= nil then
      update_dialog_from_manifest(local_manifest, "LOCAL FALLBACK")

      local reason = tostring(online_state or "UNKNOWN")
      DisplayMessageBox(
         "BE.TECH Online Update\n\n" ..
         "לא ניתן לבצע כרגע בדיקה אונליין.\n" ..
         "המערכת עברה ל-Local Manifest.\n\n" ..
         "Reason: " .. reason ..
         "\nInstalled: " .. APP_VERSION ..
         "\nLocal Latest: " .. tostring(local_manifest.latest_version or "-")
      )
      return true
   end

   dialog:UpdateLabelField("UpdateStatus", "UPDATE CHECK FAILED")
   dialog:UpdateLabelField("HubUpdateStatus", "UPDATE CHECK FAILED")
   dialog:UpdateLabelField("UpdateSource", "-")

   DisplayMessageBox(
      "BE.TECH Online Update\n\n" ..
      "בדיקת העדכון נכשלה וגם לא נמצא Manifest מקומי.\n\n" ..
      "Online: " .. tostring(online_state or "-") ..
      "\nLocal: " .. tostring(local_state or "-")
   )

   return true
end


function main(path)
   g_script_path = path
   refresh_license()

   local saved_folder, saved_post, saved_drills = load_settings()

   dialog = HTML_Dialog(
      false,
      "file:" .. path .. "\\SyntecConverter.html",
      900,
      900,
      "BE.TECH CNC Tools Hub"
   )

   dialog:AddTextField("LoginUser", "")
   dialog:AddTextField("LoginPass", "")
   dialog:AddLabelField("LoginStatus", "")
   dialog:AddLabelField("AuthState", "LOCKED")
   dialog:AddLabelField("LicenseCustomer", license_customer())
   dialog:AddLabelField("LicenseStatus", license_status_display())
   dialog:AddLabelField("LicenseStateCode", tostring(g_license.eval.state or "-"))
   dialog:AddLabelField("LicenseExpiry", license_expiry_display())
   dialog:AddLabelField("MachineID", machine_id())
   dialog:AddLabelField("LicensedMachineID", tostring(g_license.machine or "-"))
   dialog:AddLabelField("AppVersion", APP_VERSION)
   dialog:AddLabelField("LicenseID", tostring(g_license.license_id or "-"))
   dialog:AddLabelField("LicensedUser", tostring(g_license.login_user or "-"))
   dialog:AddLabelField("LicensedModules", licensed_modules_display())
   dialog:AddLabelField("SyntecModuleStatus", syntec_module_status())
   dialog:AddLabelField("LicenseSignature", tostring(g_license.signature or "-"))
   dialog:AddLabelField("LicenseStatusMain", license_status_display())
   dialog:AddLabelField("SyntecModuleStatusMain", syntec_module_status())
   dialog:AddLabelField("HubSyntecStatus", syntec_module_status())
   dialog:AddLabelField("HubSlotStatus", slot_generator_hub_status())
   dialog:AddLabelField("HubFutureStatus", future_tools_hub_status())
   dialog:AddLabelField("HubCabinetStatus", cabinet_system_hub_status())
   dialog:AddLabelField("HubHingeStatus", hinge_drill_hub_status())
   dialog:AddLabelField("HubLicenseStatus", license_status_display())
   dialog:AddLabelField("HubModulesDisplay", licensed_modules_display())
   dialog:AddLabelField("HubAppVersion", APP_VERSION)
   dialog:AddLabelField("HubAppVersionFooter", APP_VERSION)
   dialog:AddLabelField("HubCustomer", license_customer())
   dialog:AddLabelField("HubLicenseID", tostring(g_license.license_id or "-"))
   dialog:AddLabelField("HubExpiry", license_expiry_display())
   dialog:AddLabelField("HubMachineID", machine_id())
   dialog:AddLabelField("HubUpdateStatus", update_status_text())
   dialog:AddLabelField("UpdateStatus", update_status_text())
   dialog:AddLabelField("LatestVersion", update_latest_version())
   dialog:AddLabelField("UpdateChannel", update_channel())
   dialog:AddLabelField("UpdateSource", update_source_text())
   dialog:AddLabelField("DownloadStatus", "READY")
   dialog:AddLabelField("DownloadedFile", "-")
   dialog:AddLabelField("PrepareStatus", "NOT PREPARED")
   dialog:AddLabelField("PreparedVersion", "-")
   dialog:AddLabelField("InstallStatus", "NOT STARTED")
   dialog:AddLabelField("ActivationStatus", "")
   dialog:AddLabelField("AppVersionMain", APP_VERSION)
   dialog:AddTextField("OutputFolder", saved_folder)
   dialog:AddDirectoryPicker("SelectFolder", "OutputFolder", true)
   dialog:AddTextField("OutputName", get_job_name())
   dialog:AddTextField("OutputFile", "")
   dialog:AddTextField("DrillTools", saved_drills)
   dialog:AddLabelField("Status", "מוכן לייצוא ישיר | שם העבודה נטען מה-Job")
   dialog:AddLabelField("Report", "")

   dialog:AddTextField("InputFile", "")
   dialog:AddFilePicker(false, "ChooseInput", "InputFile", true)

   populate_posts(dialog, saved_post)

   dialog:ShowDialog()
   return true
end
